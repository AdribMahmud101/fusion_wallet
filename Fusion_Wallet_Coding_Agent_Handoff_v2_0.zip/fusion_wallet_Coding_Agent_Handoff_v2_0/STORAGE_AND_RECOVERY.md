# Durable storage and recovery

## Stores and ownership

The wallet APK uses a Room/SQLite WAL database for private obligations, drafts, confirmed views, decisions, plans, queue references, outbox and evidence metadata. The signer APK uses a different private Room/SQLite database for protected configuration, keys (ciphertext references only), nonce/fee reservations and signed-attempt bytes. Inference stores only verified models and bounded ephemeral request context. No database or raw signing file is shared across UIDs.

Use FULL synchronous durability for transaction journals, foreign keys and transactional state transitions. Supply Rust with explicit journal read/write adapters; never retain the old fail-open JSON ledger as a parallel authority. WAL file/backup behavior is part of lifecycle testing. Disk-full/write error fails the operation before signing or sending.

Required tables:
- obligation(id, revision, amountRaw, dueAt, privateLabel, status, commitmentRoot, ownerTxRef).
- policy_view(chainId,wallet,epoch,policyHash,root,reservedRaw,confirmedBlockHash).
- decision(id, requestId, routeEpoch, snapshotHash, candidateSetDigest, selectedId, modelIdentity, ahemReport, status).
- plan(id, actionDigest UNIQUE, exactActionJson, requiredTier, state, queueTx, readyAt, expiresAt).
- worker_attempt(idempotencyKey UNIQUE, canonicalRequestHash, signerAttemptId, operation, state, txHash).
- outbox(id UNIQUE, aggregateId, eventType, payloadHash, createdAt, deliveredAt).
- protected_attempt(attemptId PRIMARY KEY, idempotencyKey UNIQUE, canonicalRequestHash, signerRole, eoa, nonce, operation, actionDigest, rawBytes, txHash, feeReserved, state, blockHash).
- protected_latch(singleton, incidentGeneration, reasonCode, observedAt, ownerResumeRef).
- evidence(caseId/decisionId, artifactPath, sha256, visibility, sourceCommit).

Use decimal strings for uint256 persistence. Add unique constraints for active signer EOA nonce and idempotency keys. Explicit status-transition checks and compare-and-swap prevent concurrent workers advancing the same attempt twice. Separate plan status from EOA attempt status.

## States

Plan: DRAFT -> PLANNED -> AWAITING_OWNER or QUEUE_SUBMITTING or READY. QUEUE_SUBMITTING -> QUEUED_WAIT only after queue receipt/event; QUEUED_WAIT -> READY only after chain readyAt and fresh checks. READY -> EXECUTING -> RECONCILED. Alternative terminals: HELD, BLOCKED, CANCELLED, EXPIRED, INVALIDATED. UNKNOWN is an unresolved attempt overlay, never a terminal failure or permission to create a replacement.

Attempt: INTENT_PERSISTED -> PREPARED -> BROADCAST_REQUESTED -> BROADCAST or UNKNOWN -> MINED -> CONFIRMED -> RECONCILED/REVERTED. REORGED returns to UNKNOWN pending reconciliation. RETIRED_UNSENT and INVALIDATED_KEY_RETIRED require the explicit proofs in signer protocol.

## Cross-store crash protocol

| Crash boundary | Recovery |
| --- | --- |
| Worker commits intent, no signer call | Retry same idempotency key |
| Signer persists PREPARED, response lost | Lookup same key; receive same handle/hash, never new nonce |
| Worker has handle, no broadcast request | Recheck authority and either broadcast same bytes or retire via proof |
| Signer records BROADCAST_REQUESTED, process dies before/after RPC | UNKNOWN; query hash/nonce/chain; no new financial action |
| RPC accepted bytes, response lost | Reconcile computed hash; repeat exact bytes only if allowed and still valid, never a new EOA transaction for the same action |
| Receipt arrives before worker write | Recover via protected attempt/hash and canonical event scan |
| Queue event mined, worker dies | Read contract queue at startup; do not restart delay from local time |
| Owner cancellation and execute race | Canonical transaction order decides; reconcile both; never mark cancelled solely on button press |
| Storage corrupt or unsupported version | Latch, preserve damaged files, restore only with full chain/journal reconciliation |
| Reinstall/data loss | No automatic resume; old sessions must be revoked from a retained owner identity; fresh deployment if identity lost |

No blocking network call is made while holding the transaction that persists the halt latch. Retrying an outbox event is idempotent. A failed UI notification does not alter financial state.

## Canonical reconciliation

Require receipt.status=1, correct destination/selector, expected sender/EOA nonce, matching ActionExecuted or ActionQueued event, digest/epoch/session/actionNonce and exact amount/vault/share fields. Five canonical confirmations is the demo rule. Record receipt block hash, confirm ancestry and recheck for at least 64 blocks; deeper divergence halts for full rescan from deployment. Do not call this irreversible finality.

Asset reconciliation uses transaction-level logs/traces, not only end-of-block balances. Other transactions may donate to the wallet in the same block. For the pinned demo token/vaults, verified Transfer logs and ActionExecuted give per-transaction changes; reconstruct starting balances through all intervening transfers, or use a supported trace. If required history is unavailable, pause with ACCOUNTING_UNCERTAIN. An event alone is insufficient if observed share/cash effects disagree.

Queue transactions move no treasury assets and do not consume action budgets; they consume gas and create an obligation to reconcile queue state. Execute charges the gross amount once. Cancel/expiry consumes the action nonce but not the financial budget. Reverted transactions consume gas, not successful action volume. Preserve used native fees after errors.

## Nonce and fee rules

One unresolved transaction per EOA for agent, owner and guardian independently. Never assume pending nonce from a single RPC is canonical proof of no transaction. No automatic fee replacement in the base. Same signed bytes may be rebroadcast under bounded retry with status visible. If authority expires while exposure is uncertain, keep the attempt unresolved, revoke/retire key and continue scanning; do not release its nonce/fee reservation as if it never existed.

After explicit revocation is canonically confirmed, an old queued/approved action cannot execute under the new epoch. This does not prove its earlier execution never happened. Scan ActionExecuted and nonce/receipt history through the revocation block and its confirmation depth. A reorg of that revocation reopens uncertainty and halts the replacement session.

## Retention and export

No prompts, invoices, latent snapshots, keys or raw signed bytes in public evidence. Retain sanitized case/decision logs for the submission; local private history has explicit delete/export controls. Delete-on-request cannot erase public-chain events. Source build/debug logs are scrubbed before sharing. Inference history clears between financial tasks and on lock/halt; bounded local telemetry stores counts/timing/identity only.
