# Next coding agent TODO

Work in Fintech_Wallet_Agent; read AGENT_HANDOFF.md first. Each item needs implementation, tests and evidence before it is checked off.

- [ ] J00 Pin all three commits/toolchains; capture current app screenshots and clean build/test baseline.
- [ ] J01 Fix MNN CI’s ABI selection; prove real arm64 load/chat, lifecycle and final AAR packaging.
- [ ] J02 Replace float/key-string/transfer-only product contracts; add typed Rust preview, raw units and V3 DTOs; regenerate UniFFI.
- [ ] J03 Implement DemoUSD, two demo vaults and RestrictedTreasuryWallet V3 with reserves, three tiers, queue and recovery; run direct bypass/invariant tests.
- [ ] J04 Add signer APK, trusted owner review, protected journal and typed Binder authentication; remove raw-key UI path.
- [ ] J05 Add inference APK and verified model provisioning; implement serialized real MNN candidate selection and privacy/late-result tests.
- [ ] J06 Connect pinned snapshots, deterministic candidates, obligation ledger, policy mirror and exact preview; remove fixture health/balances from real mode.
- [ ] J07 Implement durable worker/sign/broadcast/reconcile and crash/reorg recovery; prove exactly-once effect under unknown transmission.
- [ ] J08 Connect all five PDF enhancements to real state: buckets, arena, cancel panel, decoded cards and ASR/FBR table.
- [ ] J09 Integrate AHEM in SHADOW, then ENFORCED only after native-hook, calibration and held-out gates; no automatic claim promotion.
- [ ] J10 Run release/device/Anvil/testnet gates, collect real receipts and sanitized evidence, rehearse five-minute demo and ten-minute presentation.

Do not check a task complete because files compile, a screen renders, a mock passes or a required test was skipped. Record BLOCKED with the exact prerequisite when a tool/device/model is unavailable. NEXT_AGENT_TODO is a summary; detailed acceptance is in acceptance_tests.csv.
