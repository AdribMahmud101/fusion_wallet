# AHEM integration and research claim boundary

## What is being added

AHEM maps model activations into rule evaluation and can refuse a decode step. In fusion_wallet it provides an extra veto layer and measurable telemetry. It does not prove that a latent coordinate means “safe”, that a model cannot be injected, or that a transaction is authorized. Exact integer policy, signer checks and Solidity enforcement remain mandatory in every mode.

Modes:
- OFF: no AHEM evaluation; UI says disabled.
- SHADOW: real callbacks and scores recorded, decisions do not alter output; UI says observation only.
- ENFORCED: callbacks cover the required decode span and a veto stops/discards the output before any tool use.
- ERROR/UNAVAILABLE is a runtime condition, not an implicit fallback from ENFORCED to OFF.

The core profile can ship with AHEM OFF and honest documentation. A “tensor-enforced” or full research profile cannot pass without the live gates. Failure to finish AHEM is disclosed as unfinished work, not replaced with a fake green badge.

## Required native integration

Create a pinned fork/build of upstream MNN 3.6.1 and a reproducible patch series. The SDK’s bundled binaries do not contain AHEM’s imported functions. Do not attempt to call unknown symbols dynamically and swallow the error.

Minimal release hook is veto-only. Avoid making KV rewind/token-ban correctness a dependency of the base demo. Add a small dedicated AHEM mobile FFI adapter that uses grounding/TensorLogic and a versioned callback ABI without pulling in the legacy ahem_llm_* session runner. Keep experimental rollback behind a separate feature and test profile.

Suggested C ABI contract (normative behavior, implementation still NEW):
- ahem_hook_abi_version() -> uint32, expected 1.
- ahem_register_gate_v1(sessionHandle, callback, userData) -> status.
- ahem_unregister_gate_v1(sessionHandle) -> status, drains all callbacks before returning.
- Callback arguments: session ID, request generation, decode step, const float* data, uint64 elementCount, rows, cols, layout/dtype tag and userData.
- Callback returns ALLOW=1 or VETO=0 only. Internal errors are VETO and set a diagnostic code.
- ahem_get_coverage_v1(sessionHandle, report*) reports first/last steps, callback count, veto/error, current generation and whether final output was gated.

A callback receives a contiguous host-readable FP32 tensor whose shape and byte length are checked before constructing a Rust view. For GPU/packed/FP16/quantized paths, convert and synchronize into a session-owned staging buffer. Keep it alive and immutable through the synchronous callback. No pointer is retained by Rust. If a zero-copy CPU path is proved, label only that boundary zero-copy; mapv/grounding/evaluation can allocate.

Place the callback at a documented pre-lm-head activation point and enforce its veto before sampling/emitting the corresponding decision token or dispatching any tool. Store the exact patched source location, tensor name/shape and model-export identity. If the exported graph fuses or hides this tensor, change/export the model graph and verify the new artifact; a generic output/logit hook must not be presented as pre-lm-head interception.

The supplied template’s getter lock does not remain held after return. Replace that contract or avoid it with synchronous callbacks. Do not fill the missing release function with a no-op. Validate bounds including multiplication overflow, alignment, dtype and maximum tensor bytes; reject NaN/Inf rule inputs, dimension mismatch and stale session IDs. Catch Rust panics at the boundary and veto. Serialize register/run/unregister; reject multiple active sessions unless proved independently safe.

No BSPWM lookup, subprocess, shell, filesystem write, network call, dynamic rule activation or unbounded allocation in the callback. Preallocate bounded buffers where practical and measure overhead. Store only bounded summary telemetry by default; raw latent arrays can contain sensitive information and are not exported.

## Grounding and calibration

Remove hardcoded 1,024/32x32 assumptions. ModelCapabilities declares actual hidden width and export layout. Grounding schema, selected layer, projection and rule pack are bound to model/weights/tokenizer/quantization hashes. A model update invalidates calibration and prevents ENFORCED readiness.

The repository’s eight-dimensional sample dataset is useful for unit exercises, not proof of treasury semantics. Capture labelled activations from the selected runtime using synthetic private treasury scenarios. Split by scenario family into training/calibration and an untouched evaluation set. Paraphrases of a held-out family cannot leak into training.

Store the complete learned projection w, scale, bias, thresholds, feature dimension, layer/layout identity, dataset split IDs/hashes, training config, code commits and model digest. Fix ahem_calibrate’s current omission of w and same-data “verification”. Reject empty/one-class datasets, invalid labels, inconsistent lengths and nonfinite values; division by zero or NaN metrics fail validation. Test serialization round-trip produces identical scores.

Do not allow learned/synthesized rules to relax hard policy. Dynamic rule candidates remain STAGED, require explicit review and regression evaluation, and cannot activate during a live session. If activation is later supported, increment ruleSetVersion/routeEpoch, invalidate pending decisions and restart calibration checks. Production-like private data is not used in the demo corpus.

## Privacy routing

The existing SemanticRouter is an experiment, not a privacy boundary. Deterministic data classification decides whether a task is eligible for public cloud help. A latent router may suggest local handling, but cannot label financial text public or authorize egress. Financial and critical tasks are always local independent of AHEM score.

## Required proof

1. ABI/symbol check on final arm64 APK and native version handshake.
2. Forced veto using a deterministic synthetic callback trigger stops generation and yields no accepted candidate or signer call.
3. Valid decode shows nonzero callback count, matching session/generation and complete required coverage.
4. Missing callback, registration failure, invalid shape, NaN, callback panic, stale generation or zero coverage in ENFORCED yields HOLD.
5. Lifecycle: unregister during activity drains safely; repeated load/unload and concurrent-call rejection do not crash; no stale callback pointer survives.
6. Pinned model plus held-out malicious/benign dataset; publish per-case ASR/FBR, availability and overhead. A callback-trigger test alone is not semantic safety evidence.
7. Ablation: identical seeds/corpus/model for MNN-only, MNN+deterministic policy and MNN+policy+AHEM. Separate model proposal safety from end-to-end contract safety.
8. Existing ignored live research tests are explicitly executed when their legacy full-hook profile is advertised. Veto-only mobile integration uses its own real-device tests; do not claim legacy rewind passed from these.

Rollback remains an optional extension. To claim it, prove token bans, single-step KV/history rewind, retry limits, restoration on failure, no duplicated output and equivalence of continued state against a clean replay. Returning status code 2 without a native implementation is not rollback.

## Deadline rule

Complete the core vertical slice before extending latent hooks. In parallel work by humans, AHEM can proceed on a separate branch, but this handoff does not require autonomous agent delegation. Freeze the release mode before recording the demo. If ENFORCED evidence is missing, retain the real core product and disclose AHEM as SHADOW/experimental or unfinished. Never lower a threshold solely to manufacture ASR=0 or hardcode outcomes for the demo prompts.
