# Requested enhancements and evidence mapping

Source: the supplied three-page enhancement report, “Create a short report that what must should be enh....pdf”. These are requirements, not existing implementation claims. Event scoring and submission expectations come from the supplied earlier planning/event materials, as recorded in BENCHMARK_AND_DEMO.md; recheck the organizer’s official submission surface before submission.

| Requirement | Architecture and implementation | Required acceptance IDs | Judge-visible result |
| --- | --- | --- | --- |
| E1 SME reserves and accounts payable | M0 obligations; M1 cash reads; M3 reserve checks; on-chain commitment; three buckets | OBL-01 through OBL-06; contract reserve invariants | Exact free/reserved/deployed totals and an owner-confirmed liability commitment |
| E2 Live attack arena and Chaos Switch | M1 reflex; M6 arena; isolated naive comparison; real rejection events | ARENA-01 through ARENA-04; direct contract bypass and aggregate-cap cases | Judge-selected injection, scenario depeg and cap/drip attempts with evidence of the enforcing layer |
| E3 Amount tiers and cancellation | M3 classification; M4 contract queue; M5 recovery; M6 pending panel | QUEUE-01 through QUEUE-12; UX-05; CHAIN-02 | Up to 10 immediate; over 10 through 100 delayed 180 seconds; over 100 exact owner approval; limits always apply |
| E4 Decoded intent cards | Pure Rust preview and independent trusted signer review | UX-01; signer consent-mutation and owner-approval cases | Exact action, vaults, amount, reserve impact, bounds, fees, deadlines and permission reason |
| E5 Benign task acceptance and false-block rate | M7 frozen 20 benign / 20 malicious cases, three repeats and ablation | EVAL-01 through EVAL-04 | Actual counts, target benign acceptance at least 90%, observed ASR target zero, retained errors and denominators |

Additional requested innovations: MNN private local handover is specified in ANDROID_AND_MNN.md and contracts/ipc.schema.json; tensor-level AHEM integration is specified in AHEM_INTEGRATION.md. Both use the existing repositories rather than assuming new imaginary APIs. AHEM ENFORCED is unavailable until the 11 research cases pass on the exact runtime/model/device.

Read acceptance_tests.csv for the full per-case stimulus, expected outcome, job and environment. Every definition begins NOT_RUN. A linked row is a test obligation, not evidence of a pass.
