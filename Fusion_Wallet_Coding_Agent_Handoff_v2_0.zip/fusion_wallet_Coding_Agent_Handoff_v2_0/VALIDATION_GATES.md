# Strict validation and release gates

## What has actually been verified

This architecture task performed repository/source review, the Rust source no-mock audit, native symbol inspection and GitHub CI inspection. The audit passed; the SDK CI run failed its cross-ABI-suspect import check after a successful AAR build. No integrated Rust, Android, model, AHEM-native or Solidity application tests were executed here.

Package/schema/reference-vector validation is separate from application validation. acceptance_tests.csv has 133 definitions: 119 core, 11 research and 3 optional public-cloud cases. Every runtime case begins NOT_RUN. The definition of a test is not evidence it passed.

## Profiles and release rule

- core requires all 119 core cases: real MNN plus all five PDF enhancements, protected signing, contracts and recovery.
- full requires core plus all 11 AHEM research cases. A tensor-enforced product claim requires this profile.
- --include-cloud adds the three public-cloud cases to either profile. Without them, HYBRID_PUBLIC is disabled in the build.

All required cases must be PASS with evidence from the final release build. FAIL, BLOCKED, NOT_RUN, SKIPPED, zero assertions, nonzero command exit, missing/hash-mismatched artifacts or wrong environment prevent release. Do not weaken the profile while retaining the stronger marketing claim.

The supplied verifier checks report integrity and completeness; it cannot prove that a malicious author did not fabricate a log. CI and human review must inspect the attached command outputs, real-device video and chain evidence. No document or test policy can guarantee absence of bugs.

## Required command families

Commands are run from the appropriate repo root. Future app/contract test runners below must be implemented by the coding agent; absence is BLOCKED, not a command to ignore.

Wallet Rust:
- cargo fmt --check
- cargo clippy --all-targets --locked -- -D warnings
- cargo test --locked
- cargo test --locked --release
- cargo doc --locked --no-deps
- python3 scripts/audit_no_mocks.py
- Regenerate UniFFI from release library and diff generated bindings.

MNN SDK:
- ./gradlew :mnn-sdk:assembleRelease :mnn-sdk:testReleaseUnitTest :mnn-sdk:lintRelease :sample:assembleRelease
- ABI-matched ELF import checker; verify each published ABI, not the first bridge found.
- Dedicated mandatory connected arm64 tests with exact model files. SDK assumeTrue tests alone do not satisfy this.

Integrated Android (NEW modules/tests):
- ./gradlew :app:assembleRelease :app:lintRelease :inference:assembleRelease :signer:assembleRelease
- Host/JVM tests for schemas/state mappings.
- Connected instrumentation on actual arm64 hardware for Binder isolation, native inference, owner consent, lifecycle, packaged JNI and privacy.
- A clean install using the final signing certificate. Debug-only screenshot previews are insufficient.

Contracts (NEW Foundry project):
- forge fmt --check
- forge build
- forge test -vvv
- Unit, fuzz and invariant suites with recorded seeds and adequate case counts.
- Real Anvil process integration including direct bypass, queue time boundaries, revert receipts, unknown-send and reorg faults.
- Base Sepolia vertical slice and cancel receipts on disposable test assets.

AHEM:
- cargo test --locked
- cargo test --locked --features tensorlogic
- Mobile veto-only adapter real native/device suite (NEW).
- Legacy ignored mnn-ffi live/rollback tests only if that complete feature is claimed; explicitly use --ignored in a prepared patched-runtime environment.
- Held-out calibration/ablation and complete artifact round-trip.

Capture actual output, start/end time, tool version, command exit code, discovered/passed/failed/skipped counts and relevant device/model/build identity. Commands run on different commits or different native artifacts do not validate the final release.

## Gate runner and evidence layout

Implement a CI driver that translates actual JUnit/Cargo/Foundry/device results into results.json. Map each acceptance ID to concrete test names. Keep the raw reports, not just a summary string.

Each PASS entry requires:
- exact case ID and expected environment;
- nonempty executed command and exitCode=0;
- assertions>=1 and skipped=0;
- testNames identifying real assertions;
- device/model/chain identity as appropriate;
- at least one nonempty evidence file with SHA-256.

The report records releaseCommit and integrationLockSha256. integration-lock.json must resolve native hashes, model identity and actual deployed contracts. The verifier compares the recorded lock hash and checks required fields; CI must compare releaseCommit to its checked-out git HEAD before reporting.

Run:
~~~text
python3 verification/verify_release.py results.json --evidence-root evidence/run   --lock integration-lock.json --profile core
~~~
For full tensor-enforced claims add --profile full. Public-cloud build adds --include-cloud.
results.template.json MUST fail. Do not edit its NOT_RUN entries to PASS manually.

## Strict oracles

Unknown broadcast is unresolved even when an RPC returns an error. Receipt.status=1 alone is insufficient without the right event, canonical block and transaction-level amounts. A queue receipt is not an executed rebalance. A cancelled UI request is not a confirmed chain cancel. A callback count>0 is not complete AHEM coverage. A nonempty LLM response is not correct candidate extraction. A scenario setup failure is not a defended attack.

Amounts and tier boundaries are exact to one atomic unit. Tests cover 10, 10.000001, 100, 100.000001. Time tests cover readyAt-1/readyAt/expiresAt/expiresAt+1. Required tests exercise same-block donations, nonce ambiguity, corrupt storage, interrupted native teardown and changed owner review fields.

No mocked model satisfies real_model_device; no JVM fake satisfies android_device; no JSON fake receipt satisfies anvil/base_sepolia; no string sanitizer test satisfies network_capture; no Rust-only callback mock satisfies real_mnn_hook.

## Completion report template

Job and requirement IDs:
Commit and artifact identities:
Behavior implemented:
Commands and counts:
Evidence paths and hashes:
Failures or BLOCKED prerequisites:
Known limits and disabled features:
Next job:

A job is complete only when its required acceptance cases pass and the behavior is connected to the real application path. Stubs behind the UI are incomplete even if the unit tests pass.
