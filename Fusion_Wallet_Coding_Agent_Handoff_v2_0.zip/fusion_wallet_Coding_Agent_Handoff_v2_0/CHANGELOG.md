# Version 2.0 changes and decision record

Repository review: 16 October 2026. Consolidated delivery: 17 October 2026.

This replaces the v1.0 implementation baseline while preserving it as history. The existing native application is the product base. No reviewed repository source or remote branch was modified by this documentation task.

| Decision | v2.0 outcome | Why |
| --- | --- | --- |
| Product stack | Keep Compose, Rust, Alloy and UniFFI; add inference and signer APK modules | Fits the actual repository and gives explicit Android UID boundaries |
| Sensitive inference | Real MNN in an APK without INTERNET; optional public education accepts fixed enums only | Private context has no cloud fallback; routing does not depend on an LLM privacy judgment |
| Financial authority | Deterministic Rust preview, independent signer and restricted V3 Solidity wallet | A model response or tensor ALLOW is never authorization |
| Obligations | Owner-confirmed root and total; exact three-bucket accounting | Reserved payables cannot be confused with investment surplus |
| Cancellation | Mid-tier delay and cancellation enforced on-chain | A UI timer cannot enforce the proposed 3–5 minute control |
| Signing and recovery | Signer owns keys, nonces, bytes and send journal; UNKNOWN remains reserved | Avoids raw-key UI FFI and duplicate effects after ambiguous RPC failure |
| AHEM | Separate OFF/SHADOW/ENFORCED modes; mobile veto hook, calibration and coverage gates | Current native SDK lacks the required research exports |
| Evaluation | Frozen benign and malicious cases; measured ASR, FBR and availability | Safety alone is insufficient if useful tasks are blocked |
| Completion | 133 acceptance definitions and a release verifier that rejects incomplete evidence | Agent completion must be tied to executed tests on the delivered build |

Breaking interfaces: action/policy domain V3 and signer protocol 2.0.0. Reject old V2 digests. Use a fresh disposable test deployment. The current transfer-only key-string export is excluded from the product path.

All five supplied PDF enhancements are mandatory for the core profile. AHEM native enforcement additionally requires the full research profile. Optional cloud education requires its three additional cases. There are no pre-approved exceptions to a claimed profile.

The SDK CI failure is treated as a likely ABI-selection defect in the import checker, not proof that the user’s arm64 SDK is broken. The next agent must check matched ABI pairs and run device tests before altering native declarations.
