# fusion_wallet full native base architecture
Version 2.0 | Domain and on-chain contract version 3.0.0 | Signer protocol 2.0.0

## Product and scope

fusion_wallet is a private operating-reserve and accounts-payable planning assistant for a small business. It reserves funds for obligations, allocates only permitted surplus to two demonstration ERC-4626 vaults, and makes each proposed action understandable and verifiable. Accounts payable means obligation planning and reservation in this base; automatic supplier payments, FX, bridges and real cross-border settlement are outside it.

The complete target includes all five requested enhancements: three treasury buckets, a live attack arena, three amount tiers with an on-chain cancellation window, decoded approval cards and false-block-rate evaluation. It also includes actual on-device MNN selection and an independently gated AHEM research integration. This is the target to implement, not a statement that the three source repositories already form this system.

Keep the native Compose application and Rust library. Replace the earlier web/Node/Linux deployment with native Android services and a restricted Solidity wallet. Do not create a parallel React dashboard. The current app.fusion.wallet package and Fusion visual assets can remain; use fusion_wallet as the displayed product name through resources, without mass renames.

Base scope: one owner, one treasury, one DemoUSD token with six decimals, two trusted custom ERC-4626 demo vaults, Anvil for fault injection and Base Sepolia for public receipts. No mainnet keys, real deposits, swaps, staking, arbitrary transfers, upgrade proxy or ERC-4337/paymaster in the hackathon base.

## Trust boundaries

Use three Android application modules in the existing Gradle project:

| Component | Identity and permissions | Responsibility |
| --- | --- | --- |
| Existing :app | app.fusion.wallet; network for pinned RPC and approved feeds | Compose UI, private obligation records, Rust planning/policy mirror, durable orchestration |
| NEW :inference | app.fusion.wallet.inference; separate UID; NO INTERNET permission | MNN/AHEM runtime and model files; bounded authenticated Binder API; no keys or signing API |
| NEW :signer | app.fusion.wallet.signer; separate UID; pinned RPC network | Protected keys, independent exact policy checks, signing/broadcast journal, trusted owner confirmation screen |

All three are signed with the same release certificate, have distinct UIDs and no sharedUserId. Signer/inference services use explicit component binding, a custom signature permission and exact caller UID/package/certificate checks on each incoming transaction. Capture Binder caller identity before dispatching asynchronous work. Signature permission alone is insufficient when other apps share the signing certificate. Payload limits, protocol versions and application IDs are checked too.

A same-UID :process service is not this isolation boundary. No inferred security from a Kotlin class boundary or process name. A separate inference APK keeps normal private file paths usable by MNN; this avoids assuming the unmodified SDK can read a model directory from an isolatedProcess UID. Provision model bytes via a narrow, authenticated file-transfer API before the demo; verify hashes and disallow network/file-path commands in the inference protocol.

The signer holds owner and agent keys in separate encrypted records. Android Keystore AES-GCM keys wrap software secp256k1 material. Owner unwrap requires fresh user authentication and an exact trusted signer-screen review; automatic agent unwrap is restricted to its bounded session. This is at-rest protection, not hardware Ethereum signing. Plaintext secp256k1 material exists briefly inside the signer process. No key String crosses the wallet UI or MNN boundary.

An optional guardian on a separate device can pause the contract with a separate pause-only address. The base signer also owns a pause-only guardian key for local critical events; this does not make it independent of signer compromise. A compromised signer remains a serious threat, especially because it can access owner material during an authorized owner operation. Hardware wallets/separate owner devices are a production hardening path.

~~~mermaid
flowchart TD
  UI["Compose wallet and Rust worker"] -->|"bounded private request"| AI["Inference APK without network"]
  AI -->|"candidate ID and gate status"| UI
  UI -->|"typed action and fresh state"| SIGN["Signer APK and owner review"]
  SIGN -->|"restricted transaction"| CHAIN["Treasury wallet and two vaults"]
  CHAIN -->|"canonical events"| UI
  RISK["Deterministic risk checks"] -->|"latch and pause"| SIGN
  RISK -->|"invalidate generation"| AI
~~~

## Financial authority

The local model proposes one existing candidate ID or HOLD. It never invents amounts, addresses, calldata, approvals, obligations or keys. AHEM can veto a model response; it cannot authorize funds. Rust produces a read-only preview before any key is loaded. The signer independently validates the final exact action, and the on-chain wallet enforces hard bounds even if the model/UI/worker is bypassed.

Three permission modes remain separate from three amount tiers:
- READ_ONLY: no delegated execution.
- OWNER_APPROVED: every valid action requires an exact owner approval.
- AUTONOMOUS: up to 10 DemoUSD immediate, over 10 through 100 delayed, over 100 requires exact on-chain owner approval.
- All modes obey the immutable vault universe, asset, reserve, hard, daily and session limits.

Default test policy: buffer 500; reserved obligations 1,500; immediate cap 10; delayed cap 100; hard cap 2,500; daily gross cap 4,000; session gross cap 8,000; destination exposure 6,000 per vault; session expiry at most 24 hours; delay 180 seconds. Amounts are DemoUSD units in prose and integer atomic units in code. These are demonstration parameters, not investment advice.

## Treasury buckets and obligations

Let C be actual wallet token cash, R the owner-approved active obligation total, B the operating buffer, and V the sum of marked vault holdings. The encumbrance is R, and the protected cash threshold is R+B.

Normal state C>=R:
- Liquid free cash = C-R. This includes the buffer.
- Reserved obligations = R.
- Deployed vault holdings = V.
- Sweepable cash = max(C-R-B, 0); this is a sub-label, not a fourth asset bucket.
- Total assets = C+V = free cash + reserved cash + deployed holdings.

If C<R, show backed reserve=min(C,R), free cash=0 and shortfall=R-C. Display the obligation target R separately. Never reduce the liability record to hide the deficit or count an unfunded obligation as an asset.

Reference initial state: C=5,000; R=1,500; B=500; vault A=3,000; vault B=2,000. Buckets are 3,500 free, 1,500 reserved, 5,000 deployed, with 3,000 sweepable and 2,000 protected cash.

Private invoices stay in :app storage. A draft obligation becomes active only after an authenticated owner commitment of total R and a canonical hash of approved IDs/amounts/due times is confirmed on-chain. No automatic LLM reservation or release. A text edit that changes economic fields requires new owner approval. Metadata is not uploaded to a cloud LLM. A commitment proves the approved recorded set, not completeness of the company’s real-world debts.

Reserve changes pause/revoke the session and invalidate queued/approved actions; re-plan after confirmation. Lowering R needs a decoded release card identifying each affected invoice. No scheduled expiry silently releases an unpaid liability. Base supports draft/active/settled/cancelled records; settlement is an owner-attested bookkeeping status, not proof of a supplier payment.

## Complete modules

| Module | Input | Output and owner |
| --- | --- | --- |
| M0 Mandate and obligations | Owner intent, private liabilities, exact deployment manifest | Validated draft, confirmed policy and commitment; Compose + Rust |
| M1 Perception and reflex | Pinned RPC block, token/vault/authority reads, bounded fee/risk feeds | Snapshot or halt; Rust worker and independent signer |
| M2 Local planning | Deterministic feasible candidates, necessary private context | Candidate ID/HOLD, runtime provenance, AHEM status; inference APK |
| M3 Policy and approval | Candidate, snapshot, obligations, current session/queue | Decoded preview, exact action and preflight envelope; Rust + signer UI |
| M4 On-chain authority | Typed policy/session/approval/queue/action calls | Contract rejection or constrained transaction; Solidity + signer APK |
| M5 Execution and recovery | Durable request IDs, protected attempts, chain events | Reconciled status, rollback/uncertainty, bounded recovery |
| M6 Product and evidence | Authoritative state flows | Buckets, decoded cards, queue, attack arena, decision passport |
| M7 Validation and release | Deterministic fixtures, real model/device, contracts, adversarial corpus | Actual results, ASR/FBR, receipts, release gate |

## Runtime flow

1. Owner provisions test treasury, confirmed policy and obligation commitment. Signer starts latched.
2. Owner starts a session, then explicitly resumes after health and reconciliation checks.
3. M1 reads all financial state at one block/hash. Inconsistent/missing inputs are not replaced with zero.
4. M2 deterministically enumerates at most seven feasible actions plus HOLD using integer arithmetic.
5. On-device MNN selects a candidate. No sensitive cloud routing is attempted. AHEM mode and coverage are attached.
6. M3 refreshes state. An unchanged action can use a new short-lived envelope; any changed amount/vault/bounds/deadline requires a new digest/decision and approval when needed.
7. Immediate actions execute; middle actions are queued on-chain; larger actions await on-chain exact owner approval. Hard limits remain binding.
8. M5 durably coordinates signer nonce/bytes/broadcast, then waits for canonical receipt and transaction-level accounting.
9. M6 shows measured results and traceable evidence. HOLD is a successful safe decision when correct; it is not counted as task execution.

Critical conditions bypass the model: persist the halt latch, stop new prepare/broadcast authorization, invalidate generation IDs, request on-chain pause, then ask the local model for an explanation. Already broadcast transactions can still settle before pause is mined. UI must distinguish local halt from confirmed chain pause.

## Privacy and optional cloud

LOCAL_ONLY is the release default. Financial goals, invoices, balances, wallet addresses, risk incidents, candidates and approvals are private local context. Keys, seeds, API secrets and signed raw transactions go to neither model. The inference APK has no network permission. RPC operators still observe public-chain requests; this is not anonymous/offline settlement.

Optional HYBRID_PUBLIC is a separate capability: only a fixed topic enum (ERC4626_BASICS, PERMISSION_TIERS, RESERVE_POLICY, TRANSACTION_STATES) can reach a public education broker. No free text, conversation history, account ID, wallet address or private context field is allowed. The broker expands a fixed public prompt and has no financial tools. This feature is disabled until payload and egress tests pass.

If a public question becomes financial, cancel the public job, increment routeEpoch and create a new private local request. Do not forward the cloud transcript or financial context. Discard late old-epoch responses. A local inference error produces HOLD; never use a cloud model as fallback for private work.

## Reliability and limits

Use one durable worker per treasury and one protected transaction attempt per signing EOA. A pending mid-tier action locks that wallet’s action nonce until executed, cancelled or expired. Queue state is on-chain; a local countdown is informative only. Do not pre-sign the execution transaction during the delay.

Android does not guarantee continuous background service or prompt delivery. Core demonstration runs with the app visible and services connected. On suspension, process death, lost IPC or stale heartbeat, signer latches; pending queue does not auto-execute. Restart reconciles first and requires explicit owner resume. Do not promise continuous unattended treasury management. Foreground-service operation can be added only with OS-version lifecycle tests.

The contract delay uses chain time. Critical halt has a measured local target (p95 <=250 ms to the persisted latch) but no claimed bound on public-network inclusion. Five canonical confirmations are a demo confirmation rule, not finality. Continue reorg monitoring.

## Migration from v1.0

Replaced: React/Vite/Fastify services, Linux Unix-socket identity, MNNCLI server assumptions and browser-only owner signer. Preserve their safety objectives through native UID/Binder isolation, signer-owned bytes and strict authority.

Added: obligation commitment, micro/delayed/owner tiers, on-chain queue lifecycle, native model capability manifest, AHEM evidence modes, live arena and benign evaluation.

Breaking changes: Policy, mandate hash and action domain advance to V3; signer protocol to 2.0.0. Do not accept V2 digests or replay old fixtures. Deploy a fresh test wallet; never migrate live funds in this sprint. The old transfer export is quarantined under a legacy/test feature and excluded from the product APK. Existing source tests are retained and extended where their behavior remains valid; tests that endorse corrupt-state reset or broadcast-as-success must change with an explicit rationale.
