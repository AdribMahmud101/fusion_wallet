# Android integration and local MNN runtime

## Build ownership

Fintech_Wallet_Agent is the integration repository. Keep its Gradle wrapper 8.13, AGP 8.11.0, Kotlin 2.0.21, Java 17, compile/target SDK 36 and minSdk 24 initially. fusion-core declares Rust 1.94; pin an installed matching toolchain and keep Cargo.lock. Do not upgrade all dependencies while connecting the pipeline.

Build the SDK in its own pinned repository using its own Gradle 8.2/AGP/Kotlin settings, then publish a local Maven artifact with its POM and checksum. Consume it in the new inference module. Local Maven must be a reproducible build output repository, not an undocumented developer cache. Record the artifact coordinate and checksum in integration-lock.json and a clean build script. AAR-only file dependencies require explicit transitive dependencies; avoid hiding this.

Product release targets arm64-v8a first. Build libfusion_core.so and AHEM/native support with compatible Android API, NDK and C++ runtime choices. Check the final APK ZIP, ELF DT_NEEDED imports and ABI. Do not resolve conflicting libc++ or libMNN copies with an unexplained pickFirst. The SDK’s JNI build uses c++_static and bundles other native libraries; record and validate the resulting final link graph.

## Native SDK release check

Fix .github/workflows/build.yml to inspect each built JNI bridge with its matching ABI library directory. Determine ELF machine/class before checking imports; validate both shipped ABIs if publishing both. The existing first-find comparison can mix ARMv7 imports with arm64 exports. Run unit tests, lint and minified consumer build even when collecting diagnostic results; final job must still fail if any required gate fails.

Resolve documentation drift only after executing device tests. Do not modify the public createFromBuffer declaration merely to appease a cross-ABI comparison. Confirm version from actual runtime and record hashes of every shipped .so.

## Inference companion application

NEW :inference module:
- Manifest has no INTERNET, no sharedUserId, no backup and no exported activity. A bound service is exported only behind the custom signature permission.
- Verify each caller’s UID/package/certificate; reject unknown clients and oversized/unknown protocol fields.
- Store verified model files in inference app-private storage so existing MNN path APIs work.
- Provide beginProvision(manifest), writeChunk(fileId, offset, bytes), finishProvision and getCapabilities. Limit total size/file count, canonical relative filenames, no symlinks or traversal, atomic temp-to-final promotion and hash verification. The only writable provisioning targets are declared model artifacts.
- Freeze provisioning while a model is loaded. A model update drains all jobs and requires new runtime identity, calibration and evaluation.
- No URL downloader, shell command, arbitrary file reader, log exporter or signing call in this API.

Provisioning can be driven by a build/setup utility or the main app after downloading a pinned public model. No private context accompanies model downloads. No download/repair occurs during a private inference request. Digest mismatch, incomplete file or unverified tokenizer prevents READY status.

Capabilities response: protocolVersion, sdkCommit, mnnVersion, ABI, library hashes, model ID/revision/config/tokenizer hashes, hiddenDimension (if AHEM), backend, available memory, supported operations, AHEM mode/hook ABI/rulepack/calibration hashes and measured health. These values come from runtime inspection, not hardcoded dashboard labels.

## API adapter and concurrency

Implement LocalPlannerClient in the wallet and SerializedMnnPlanner in inference. One native session and one in-flight generation. All load/configure/reset/chat/token metrics/close operations use a single ownership state machine. Use the SDK’s blocking chat() path initially because its current native-history behavior differs from streaming. Run off the UI thread. Do not stream raw thinking into logs or use it as a security explanation.

States: UNPROVISIONED -> LOADING -> READY -> GENERATING -> READY. Timeout/cancellation/process death enters DRAINING or FAILED; never READY while native work may still exist. Destroy only after native work has returned. A watchdog may terminate the inference process if it cannot drain; it may not free an in-use handle. Process termination invalidates all request IDs, and signer execution stays halted until a new health check and fresh decision.

Fix lifecycle gaps in the SDK on a dedicated branch if tests expose them: count every generation API; guard against use-after-close; synchronize handle ownership; make destroy idempotent and unable to free on an interrupted wait; reject concurrent calls; remove races between reset/config and decode. Native USER_CANCEL is an available cooperative signal, not a guarantee against a hung kernel.

Planner request: requestId, routeEpoch, snapshot identity, capability digest, candidate list, bounded goal, deadline. Planner response: requestId, routeEpoch, selected candidateId/HOLD, finite reasonCode, timings, output validation result and AHEM report. Compare all correlation fields before accepting. A late completion after halt is discarded, even if syntactically valid.

Use fresh task context for each financial decision. Keep an explicit bounded summary if needed; do not allow unbounded chat history to change transaction meaning. Prompt template/model-specific special tokens must be verified with the exact config; do not assume README’s old use_template=false advice still applies.

## Model selection and offline evidence

Start benchmarking with one small model already listed by the SDK, such as Qwen2.5-0.5B-Instruct-MNN, then choose the smallest model that passes the frozen candidate and benign-input gates on the actual device. This is a candidate, not a tested recommendation. Pin the exact upstream model revision, conversion/config, weights, tokenizer and license; missing identifiers block release. A 1.5B label or 118 ms fixture is never retained as measured health.

Record device model, Android version, ABI, RAM headroom, backend/threads, cold load, first token, complete candidate latency p50/p95, failure/timeout count, peak memory and thermal throttling after 20 sequential requests. Disable unsupported NNAPI/Vulkan claims until capability evidence exists.

Run planning with all network blocked for the inference UID. The request must still complete locally. Keep wallet RPC traffic separate in the capture. Test private canary strings against all permitted cloud payloads; neither full nor partial canary may appear. Do not publish raw production-like private prompts.

## Signer companion and trusted owner UI

NEW :signer has independent application storage and Rust library. Its service returns handles/results, never key material or raw transaction bytes. The old execute_intent(json, private_key:String) export is absent from production bindings or behind a non-default legacy feature unused by the APK.

Owner controls appear in a signer-owned activity. Input is a request ID, not a caller-supplied HTML card. The signer fetches and validates the canonical request, reads chain state, decodes exact calldata, shows the full critical fields, requires fresh BiometricPrompt/device authentication for its wrapping-key operation, and signs only the reviewed digest. No Binder “ownerApproved=true” field is accepted. Clipboard and screenshots of secrets are disabled; owner keys are never displayed by this flow.

For the disposable test deployment, keys are generated inside signer and wrapped with Keystore AES-GCM. A secure hardware wrapping key is reported only after KeyInfo inspection. Software secp256k1 signing remains inside signer memory and is not described as hardware-backed EVM signing. Fresh authentication protects owner unwrap; the bounded session key may sign automatically without repeated owner authentication. Backup/restore or reinstall cannot silently recreate access to the old treasury.

Native key buffers are short-lived and zeroized where owned. JNI Java byte arrays may still be copied; do not claim absolute memory erasure. Never route a hex private key through Compose, logs, analytics, saved state, JSON or model context.

## Device lifecycle acceptance

Run on a real arm64 device. Exercise rotation, rapid submit/cancel, background/foreground, service death, app force-stop, memory pressure, connectivity loss, reboot and signer replacement. A non-running app cannot guarantee future execution or immediate chain pause. A cancelled Binder request may already have reached signer; resolve by idempotency ID, never assume cancellation means no transaction.

Required tests may not use assumeTrue for absent weights/device/ABI. The dedicated release runner treats absence as BLOCKED and exits nonzero. Keep generic SDK developer tests convenient, but add a separate mandatory product device suite with exact model and package checks.

Primary Android references:
- https://developer.android.com/guide/topics/manifest/service-element
- https://developer.android.com/develop/background-work/services/bound-services
- https://developer.android.com/reference/android/os/Binder
- https://developer.android.com/privacy-and-security/keystore
