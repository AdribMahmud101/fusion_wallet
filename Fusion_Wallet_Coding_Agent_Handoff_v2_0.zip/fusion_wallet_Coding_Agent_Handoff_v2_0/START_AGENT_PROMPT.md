# Paste this to the implementation agent

Continue the existing Fintech_Wallet_Agent repository using this v2.0 handoff. Read README_START_HERE.md, REPOSITORY_AUDIT.md, ARCHITECTURE.md, AGENT_HANDOFF.md and VALIDATION_GATES.md before editing. Compare repository heads against the pinned audit and preserve existing user changes.

Begin J00, then progress through NEXT_AGENT_TODO.md in dependency order. Preserve the Compose UI; integrate the real MNN SDK and typed Rust policy. Implement all five PDF enhancements with their backend enforcement. Keep AHEM OFF/SHADOW until real native-hook, calibration and device evidence permits ENFORCED.

Do not wire the old private-key String transfer export into the live UI. Do not use mainnet assets, fake transaction hashes, hardcoded model responses or fabricated metrics. Required tests must run on the actual build/device/model/chain; missing prerequisites are BLOCKED, never PASS.

For each completed job provide changed paths, behavior, acceptance IDs, exact commands/counts and hashed evidence. Continue independent work when blocked, but do not mark incomplete integration complete. Use the strict release verifier against actual results; its NOT_RUN template must fail.

The requested outcome is a working tested native testnet product and accurate evidence. Repository publication, submission and messages require separate authorization.
