# Coding agent continuation contract

## Objective

Implement the complete native fusion_wallet architecture on the existing Fusion wallet base. Preserve working UI/layout/navigation and useful tested Rust code. Finish all five PDF enhancements and integrate real MNN. Add AHEM with an explicit evidence-based mode; do not claim native tensor enforcement before it works on the shipped model/device.

This handoff is permission to continue local implementation and reversible fixes. It does not instruct deployment with real assets, repository publication, contacting organizers, sending messages or submitting the entry.

## First actions

Read README_START_HERE, REPOSITORY_AUDIT, ARCHITECTURE and VALIDATION_GATES. Inspect current repository instructions and git status. Compare current heads to evidence/source_inventory.json; if they changed, review the diff and refresh affected findings instead of applying stale line assumptions. Preserve user work and create an isolated branch/worktree when needed. Do not overwrite the three upstream repositories with generated documentation.

Capture a baseline build matrix, screenshots and failing tests before edits. Rust/Android/device/Foundry prerequisites are mandatory for their gates. Missing tools must produce BLOCKED, not a fake PASS. The architecture review’s static checks are not your application baseline.

## Ordered implementation jobs

| Job | Existing paths to inspect | New/changed work | Completion evidence |
| --- | --- | --- | --- |
| J00 Baseline | README.md, fusion-core/Cargo.toml, Android version catalog, SDK build files | integration-lock.json; explicit release flavors; toolchain/build scripts | Pinned clean builds or recorded baseline failures; reproducible dependency manifest |
| J01 MNN | SDK .github/workflows/build.yml, MNNLlm.kt, mnn_llm.cpp, instrumentation | Per-ABI symbol verification; serialized lifecycle repairs as needed; pinned AAR/POM | Native arm64 load/chat/timeout/close tests with real weights, no skipped cases |
| J02 Core contracts | fusion-core/src/models.rs, config.rs, lib.rs, guardrails.rs | NEW treasury.rs, policy.rs, amount.rs, preview.rs; typed V3 DTOs; deprecate old transfer export | Raw-unit boundary/property tests; pure preview; ABI/hash vectors; regenerated Kotlin parity |
| J03 On-chain | No contract implementation currently exists | NEW contracts/Foundry project; token/vault fixtures; wallet V3; deploy scripts | Unit/fuzz/invariant/direct-call suite; real Anvil receipts; exact reserve/queue semantics |
| J04 Signing | executor.rs, router.rs and Kotlin key seam | NEW :signer module, signer client AIDL, protected DB, owner review; typed Alloy contract calls | Unauthorized IPC rejected; no raw key in main app; unknown/crash/nonce/fee tests |
| J05 Inference | SDK public API and current IntentSource | NEW :inference module, provisioning, LocalPlannerClient, capability state, strict candidate JSON | Offline UID capture; real model selection; no stub/fixture success; stale-result rejection |
| J06 Treasury | guardrails.rs, MainViewModel, UI models | NEW perception.rs, candidates.rs, obligations.rs; Room repositories and mapping | Pinned block views, exact buckets, reserve commitment, fresh preview and economics |
| J07 Durability | router.rs, old ledger persistence | NEW orchestration.rs/reconciliation.rs, two journals, outbox and lifecycle recovery | Fault injection at every write/send boundary, reorg, no double execution or budget reset |
| J08 Product | PreFlightGuardrailCard, Tokens/Ledger/Settings/terminal | Real state flows, trusted decoded review, queue UI, NEW ArenaScreen, metric table | Existing navigation regression; five enhancement tests and accessible screenshots |
| J09 AHEM | ahem grounding/bridge/mnn_ffi/calibration/router | NEW veto-only mobile adapter, pinned MNN patch, complete calibration artifact | Real callbacks, coverage/veto/lifetime, held-out ablation; mode accurately labelled |
| J10 Release | validation scripts, final APKs and chain deployment | Strict result runner, artifact/receipt bundle, docs, slides/video | verify_release exits 0 for selected profile; public receipt and complete submission checklist |

Use bounded jobs with a working vertical slice at each milestone. Do not spend the entire deadline building abstractions before one real model decision reaches one reconciled Anvil action. Conversely, never wire the old unrestricted transfer executor into the live demo as a shortcut.

## Concrete file mapping

Retain:
- fusion-core-android/app/src/main/java/app/fusion/wallet/ui/FusionWalletApp.kt and theme/navigation components.
- Existing chat/PreFlightGuardrailCard.kt, tokens/TokensScreen.kt and ledger/LedgerScreen.kt as extension points.
- Rust strict serde parsing, Alloy ABI helpers, error patterns, tests and UniFFI generation workflow where compatible.

Replace/quarantine:
- MainViewModel default DemoIntentSource, hardcoded ready logs, fixture balances and local-only setting mutations.
- DemoData/preview fixtures move to debug/test sources. A TESTNET release cannot link the fixture intent interpreter or fabricated hash path.
- AiIntent float authority, fail-open JSON ledger, broadcast-as-success and raw private_key export.
- Unsupported Swap/Stake UI suggestions; no implied FX/payment route.

Add under fusion-core/src:
amount.rs, treasury.rs, obligations.rs, perception.rs, candidates.rs, policy.rs, preview.rs, orchestration.rs, reconciliation.rs, protocol.rs. Split crate features so the app’s pure policy/DTO library contains no key-loading export; signer includes transaction code; AHEM is not linked into the UI process.

Add under fusion-core-android:
inference/, signer/ and shared protocol sources; app data/TreasuryRepository, ai/LocalPlannerClient, signer/SignerClient, ui/arena/ArenaScreen and ui/queue/QueuePanel. New paths are design decisions, not evidence of existing files.

Regenerate fusion-core-kotlin/src/main/kotlin/app/fusion/wallet/core/fusion_core.kt from the compiled release library. Fail CI if generation changes checked-in bindings. Verify the final packaged .so matches the generated metadata, not just a desktop smoke library.

## Agent completion rules

For each job, write:
1. Changed files and resulting behavior.
2. Requirement/test IDs covered.
3. Exact commands, tool/device/model/build identities and actual exit codes.
4. Passed/failed/skipped counts; attached logs/JUnit/screenshots/receipts with hashes.
5. Remaining blockers, known defects and the next concrete action.

Do not claim “complete”, “working”, “safe”, “tests pass” or “production-ready” unless the corresponding required checks ran on the exact resulting build. Unit mocks are valid for controlled failure paths but cannot satisfy real-model, JNI, contract-bypass, privacy capture or testnet gates. Remove ignored/assumed tests from required release paths; do not remove the requirement.

If a test fails, reproduce and fix the implementation or explicitly revise a wrong test with documented reasoning. Never weaken an assertion just to get green. If tools are missing, record BLOCKED and continue independent useful work; do not invent outputs. A compile-success result does not cover runtime semantics.

Never hardcode scenario IDs, expected decisions, latency, ASR, FBR, callback counts, balances or transaction hashes to satisfy screenshots/tests. Do not introduce a test-only bypass into release code. Never catch an exception and return success or “funds unchanged” without chain proof.

Run deterministic preview before keys; do not send secrets to any model. No mainnet transaction, real treasury, cloud private fallback or automatic owner authorization. Do not add generic shell execution from AHEM or arbitrary signing methods.

## Review checkpoints and schedule

Sequence the work by dependency: foundation and contract -> real MNN/signer vertical slice -> obligations/queue/recovery -> product/arena/benchmarks -> AHEM evidence and final rehearsal. Queue/reserve logic is security-critical and larger than a UI-only 4-hour task. AHEM native patching may be the highest schedule risk; start a bounded compatibility spike early and maintain an honest OFF/SHADOW mode while core work proceeds.

Submission deadline from supplied event materials: 20 October 2026, 23:59 Beijing /21:59 Asia-Dhaka. Target a complete rehearsal and artifact freeze at least six hours before it. Stop optional model/runtime experiments after freeze. Core profile still requires all five enhancements; an unfinished one is a blocker to claiming full core delivery. If forced to demonstrate reduced functionality, label it explicitly and keep missing functionality disabled.
