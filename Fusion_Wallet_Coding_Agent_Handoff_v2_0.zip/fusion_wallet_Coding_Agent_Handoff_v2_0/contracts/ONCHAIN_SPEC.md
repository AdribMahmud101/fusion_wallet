# Restricted treasury wallet V3

This is the normative contract behavior. The accompanying Solidity interface is a design contract, not compiled implementation. Implement with a pinned OpenZeppelin release, SafeERC20 and reentrancy protection; lock compiler/dependencies and validate the final bytecode. Only a fresh disposable test deployment is authorized by this handoff.

## Deployment and immutable scope

Constructor fixes owner (nonzero), DemoUSD asset (six decimals), deployment chain ID and exactly two distinct trusted vaults. Validate vault.asset(), nonempty code and record runtime code hashes. No proxy, delegatecall, generic execute, arbitrary recipient, swap/router call or arbitrary ERC20 approval. Reject zero addresses, asset-as-vault, identical vaults and unsupported decimals. Default paused/unconfigured with sessionKey=0.

Use only known custom demo token/vaults. Fee-on-transfer/rebasing assets and upgradeable/untrusted vaults are unsupported. A malicious or illiquid vault is still a material risk even with code pinning; the demo does not prove safety of external protocols.

## Policy and obligation commitment

Policy fields and tuple order are fixed in the interface:
permissionTier, operatingBufferRaw, microMaxRaw, delayedMaxRaw, hardMaxRaw, dailyLimitRaw, delaySeconds, maxShareSlippageBps, guardian, vaults.

Validate 0<microMax<=delayedMax<=hardMax<=dailyLimit; delaySeconds in [180,300]; tolerance <=1000 bps; guardian nonzero and distinct from owner/session; one or two allowed vault limits from the immutable universe sorted ascending by address, each cap>0. Default values are 10/100/2500/4000, delay=180.

setObligationCommitment(root,reservedRaw) is owner-only. Root binds the active ledger; contract enforces the declared total, not the private records. Require root!=0 (the empty-set root is a nonzero Keccak hash). Reserved total may exceed current cash, so obligations can honestly show a shortfall. Such state prohibits spending/deposit/rebalance and permits safety withdrawal back to cash. Setting commitment revokes session, pauses, invalidates queue and increments policyEpoch. configurePolicy does the same and preserves cumulative daily usage and actionNonce except queue invalidation. No unapproved liability release.

Effective cash floor=operatingBufferRaw+reservedObligationsRaw with checked addition. A private ledger whose computed root/total differs from chain cannot plan or sign.

## Session and pause lifecycle

- configurePolicy: owner-only; validates, pauses, clears active session and queue, increments epoch once.
- setObligationCommitment: owner-only; same invalidation behavior.
- startSession(key,expiresAt,limit): configured, paused, no active key; key distinct from owner/guardian; now<expiry<=now+24h; limit>0. Increment epoch, set sessionStartEpoch, session ID, used=0; remain paused.
- resume(expectedEpoch): owner-only, paused, exact current epoch, live session; increment epoch and unpause. Preserve session start ID/expiry/usage and daily usage. No automatic renewal.
- pause(reason): owner or guardian. First transition pauses, invalidates pending queue and increments epoch. Repeated pause is idempotent and does not advance epoch again.
- revokeSession: owner-only even after expiry; pauses, clears session and queue, increments epoch. Explicit revocation is required for key rotation/recovery.
- start/resume cannot reset daily spent or action nonce.
- queue invalidation consumes its reserved action nonce by incrementing actionNonce once and emits an invalidation event. A cancellation/expiry also consumes that nonce. This prevents reusing an old queued action with the same digest.

Mutating public methods are nonReentrant or structured so all external calls occur under one shared reentrancy guard. No token callback can call policy/approval/queue/recovery mutation in the middle of execution.

## Action shape and digest

Action fields: kind, sourceVault, destinationVault, assets, minSharesOut, maxSharesBurn, expectedNonce, policyEpoch, deadline. All integer amounts/nonces are uint256; deadline uint64; kind uint8 via enum. V3 digest additionally binds chain, wallet, current mandate/session/policy/obligation commitment through the hash formulas. Hashing uses ABI encoding and Keccak-256, never JSON stringify or packed concatenation. No EIP-712 signature is required for approveAction: it is a typed on-chain owner transaction; do not label a raw Keccak digest EIP-712.

DEPOSIT uses source=zero, destination=allowed vault, minSharesOut>0, maxSharesBurn=0.
WITHDRAW uses source=allowed vault, destination=zero, minSharesOut=0, maxSharesBurn>0.
REBALANCE uses both distinct allowed vaults, both share bounds>0.
HOLD is not a Solidity action and never signs.

## Three-tier execution

Classification is always based on assets, not a model risk label. All actions obey hard/day/session caps and permission mode. Gross volume counts assets once per action; withdrawals count; a rebalance counts once, not twice.

| Amount | AUTONOMOUS | OWNER_APPROVED |
| --- | --- | --- |
| <=microMax | Immediate execute | Exact approval then immediate execute |
| >microMax and <=delayedMax | queueAction then delay then execute | Exact approval plus mandatory queue/delay then execute |
| >delayedMax and <=hardMax | Exact approval then execute | Exact approval then execute |

READ_ONLY rejects queue and execute. Direct execute of a mid-tier action without the matching on-chain queue always reverts QueueRequired, including when owner approval exists.

Immediate micro action deadline must be within 120 seconds of execution. For large actions, approveAction accepts validUntil<=action.deadline<=now+900; execute requires unexpired approval/deadline and current state. Session expiry bounds all deadlines. For queued actions, queueAction requires deadline>=now+delay+30 and <=now+delay+900 and <=session expiry. The delay therefore does not conflict with a short preflight envelope. Preflight expires in 30 seconds; the exact queued action has a longer bounded lifetime.

approveAction(Action,validUntil) is owner-only, current nonce/epoch/session, valid action shape; it stores a digest-bound expiry and emits the digest/nonce/epoch. Reapprove identical digest may extend only within action.deadline. It cannot waive any limit or delay. revokeActionApproval clears only that digest. Approvals are consumed on successful execute; a revert does not consume them. Permission/epoch/obligation changes invalidate old digests.

## On-chain cancel window

Exactly one pending queue per wallet. queueAction is session-key-only and reserves the current action nonce without incrementing it. Validate all hard rules and required owner approval at queue time. Queue stores digest, exact Action, sessionId, readyAt=block.timestamp+delaySeconds and expiresAt=action.deadline. No assets move; usage is not yet charged. All other delegated actions are blocked while a queue exists, preventing budget/nonce overbooking without a multi-queue accounting design.

cancelQueuedAction(digest) is owner/guardian-only. Require exact current digest, clear queue, consume action nonce and emit QueueCancelled. It does not release already executed assets or roll back chain history. Agent may request cancellation through UI but cannot forge an owner/guardian result.

expireQueuedAction() is permissionless only after block.timestamp>expiresAt; clear/consume nonce/event. Policy change/pause/revoke also clears/consumes queue. Receipt reconciliation must handle an invalidation event rather than waiting forever.

execute(Action) for a queued action requires exact stored digest and tuple, same session, now>=readyAt and <=expiresAt, valid approval if needed, current rule checks, current liquidity/previews and bounds. Clear queue and charge usage/nonce atomically with successful execution. Revert rolls everything back. Owner cancellation and execution racing in the same block obey canonical transaction order; UI cannot promise cancellation until its receipt is confirmed. No local timer can shorten the chain delay.

Queue and execution transactions have distinct EOA nonces and hashes. The queue event is not an asset movement. When the app dies, a queued action remains cancellable/expirable, but no background execution is guaranteed.

## Checks and asset accounting

Checks before external asset calls: configured, current chain, unpaused, caller=sessionKey, live session, non-READ_ONLY, exact epoch/actionNonce/deadline, valid immutable/allowed vaults and code hashes, asset identity, action shape/positive assets, hard limit, UTC-day gross cap, session gross cap, tier approval/queue, current cash/liquidity/exposure/share preview constraints.

For each successful action:
- UTC day=floor(block.timestamp/86400); use zero usage only for a strictly new chain day; same-day pauses/rotation do not reset it.
- SafeERC20 forceApprove exact assets immediately before deposit, then forceApprove zero. Assert residual allowance zero.
- Receiver and owner parameters are always the treasury wallet.
- Observe cash and vault-share deltas. Token return values, vault returned shares and observed shares must agree with expected positive movements.
- DEPOSIT: cash decreases exactly assets; destination shares increase by returned shares>=minSharesOut.
- WITHDRAW: cash increases exactly assets; source shares decrease by returned shares<=maxSharesBurn.
- REBALANCE: both legs atomic; net cash unchanged; source burn and destination mint exact within bounds.
- Check current preview tolerance and the original exact bounds. These are separate checks.
- End cash must remain >=R+B when it began above that threshold. If already below, only a WITHDRAW that strictly increases wallet cash is allowed; no deposit/rebalance while underfunded.
- Destination exposure after deposit/rebalance must be <=policy cap. Passive appreciation/donation above cap blocks further increases but must not block withdrawals that reduce exposure.
- Increment global actionNonce, dailyUsed and sessionUsed only on success; emit ActionExecuted with digest, pre-action nonce, session, kind/vaults/assets/share deltas/cashAfter/epoch.

Directly call the contract in adversarial tests to prove these rules work without the UI, local model or Rust. Revert selectors are evidence, not precomputed UI labels.

## Owner recovery

Only paused plus explicitly revoked sessionKey=0 plus no queue allows ownerWithdraw, ownerRecoverUnderlying and ownerRecoverShares. Recovery can access either immutable vault even if removed from current policy. Withdraw sends assets back to wallet; underlying/share recovery sends only to immutable owner. Record separate recovery events, not autonomous action success. Owner is trusted and can recover all funds; protected obligations do not restrict the immutable owner’s explicit recovery authority. Share recovery returns a claim, not guaranteed cash.

## Threat and completeness limits

Local halt cannot undo a signed/broadcast transaction. On-chain caps protect against a compromised planner/worker/session key within stated vault assumptions, but cannot prevent owner-key misuse, external vault defects, gas loss from reverting transactions or censorship. No audit/production-safety claim is made. Smart-contract fuzz/invariant tests, real Anvil bypasses and public testnet receipts are mandatory implementation gates.
