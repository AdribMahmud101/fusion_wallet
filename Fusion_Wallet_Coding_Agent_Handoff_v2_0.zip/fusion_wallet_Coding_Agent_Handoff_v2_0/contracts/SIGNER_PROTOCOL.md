# Native signer protocol version 2.0.0

Transport is authenticated synchronous Binder entry with asynchronous operation completion. Identity is checked on the Binder thread before work moves to an IO executor. JSON is a serialization format for strictly typed payloads, not a generic command language. Maximum request=64 KiB, response=64 KiB, strings bounded, unknown fields rejected. No key bytes, arbitrary destination, raw calldata, RPC URL, gas override or signing method name is accepted from the wallet app.

## Roles and operations

Automatic service operations: capabilities, status, prepare, broadcast, reconcile, halt and retireUnsent. Optional queue cancellation invokes the guardian-only cancellation path after checking the real current queue. Owner actions are not automatic service operations; requestOwnerReview creates a trusted local signer UI flow, whose approval cannot be supplied by the calling app.

prepare accepts requestId, idempotencyKey, operation (QUEUE_ACTION or EXECUTE_ACTION), exact Action, expected actionDigest/mandateHash, snapshot block identity and expiry. The signer loads its protected deployment/policy configuration, verifies current chain and code hashes, obtains current on-chain authority/queue/obligations, recomputes all hashes, checks share/cash/caps/approval/timing and simulates exact calldata with the real sender. It refuses if latched, stale, wrong runtime contract, wrong caller or already in flight.

The signer may refuse an action accepted by the worker. It may not alter the action to make it pass. A changed fee estimate can be used only within independently protected fee ceilings. It never trusts caller fee limits to expand those ceilings.

prepare response gives attemptId, operation, EOA address, EOA nonce, txHash, actionDigest, preparedAt and state=PREPARED. Signed bytes and signing material remain in signer storage. Same idempotency key plus identical canonical request returns the same attempt; same key plus different request is an error. Signer journal commit precedes the response.

broadcast accepts only attemptId and expected txHash. It checks halt state, chain/authority/expiry/fresh simulation immediately before send, persists BROADCAST_REQUESTED, and sends the already stored bytes. If refreshing fees would require new bytes, stop and explicitly retire a provably unsent attempt; do not silently mutate a prepared transaction. Unknown transmission stays UNKNOWN and reserves its EOA nonce/fees.

reconcile accepts attemptId; signer queries canonical receipt/transaction/nonce state and returns a status with block hash and observations. Worker independently reconciles the financial event and accounting. A receipt with status=0 is confirmed failure after required depth, not an execution success. Transaction disappearance after a reorg returns to unresolved state.

halt accepts incidentId, reasonCode and monotonic incidentGeneration; persist latch before acknowledging. Halt interrupts scheduling, invalidates prepared authorization and requests guardian pause. If broadcast has begun, report it as possibly in flight. No service mutex may delay latch persistence behind inference or a slow RPC. The sender checks the latch at its final local send boundary; a race after sending is disclosed.

retireUnsent requires proof that BROADCAST_REQUESTED was never persisted, the protected journal is intact, and the old authority has been explicitly revoked and canonically confirmed. Record permanent tombstone and nonce/fee release. If exposure is uncertain, do not use this operation; revoke and permanently retire the agent EOA, reconcile for any known transaction, preserve potentially consumed gas budget and create a new session key only through owner review.

Resume is an owner-screen operation, never a boolean in the request. Owner must inspect unresolved attempts, canonical revocation/queue state and current health, then confirm exact resume expectedEpoch. Latch stays set until that receipt is reconciled. Key rotation cannot erase old attempts.

## Owner transaction path

Owner screen supports configurePolicy, setObligationCommitment, startSession, resume, revokeSession, approveAction, revokeActionApproval and recovery methods. Each operation has a typed form and exact decoded preview. Signer separately journals owner EOA transactions; no owner private key is returned to the app. One owner attempt per EOA, same unknown/reorg discipline. Recheck exact review digest after authentication and immediately before signing. User cancel before signing creates no bytes; after send it means “stop waiting”, not blockchain cancellation.

Guardian path supports pause(reasonCode) and cancelQueuedAction(digest) only. It has its own EOA nonce journal and fee ceiling. Guardian cannot approve/resume/recover. Failed/unknown guardian submission does not clear the local latch.

## Protected signer configuration

Store immutable chain/wallet/asset/vault/code hashes; accepted app signing certificate/UID resolution policy; operation selector allowlist; gas limit/maxFeePerGas and maximum total native-fee reservation per session/day; session key identity; persisted latch/incident generation and journal format version. Configuration changes require trusted owner review/restart, not caller fields.

Use conservative gas ceilings for demo contracts, then measure actual gas and set documented nonzero limits before release. Do not hardcode unmeasured “zero gas” values. Reserve max possible L2 gas under transaction fields plus declared buffered L1 estimate. L1 fee is an estimate, not an absolute chain-enforced ceiling. Exhausted budget halts.

Private logs include request/attempt IDs and redacted reason codes; no secret, raw bytes, full private goal or provider credential. A crash report cannot upload native memory or model prompts.

## Health semantics

READY means configuration verified, key record accessible, journal healthy, no unresolved nonce conflict, canonical chain reachable and local latch cleared by confirmed owner resume. It does not mean the model is ready; that has its own capability check. Signer startup always begins latched. Exact states are UNPROVISIONED, LATCHED, READY, PREPARED, BROADCAST_REQUESTED, UNKNOWN, MINED, CONFIRMED, RECONCILED, REVERTED, RETIRED_UNSENT, INVALIDATED_KEY_RETIRED.

Schema contracts/signer.schema.json defines automatic prepare input. contracts/ipc.schema.json defines the remaining automatic requests, owner-review request variants, attempt responses and model-provisioning messages. Owner-review messages request a trusted UI review and never confer approval. The machine schema intentionally contains no generic “sign” endpoint.
