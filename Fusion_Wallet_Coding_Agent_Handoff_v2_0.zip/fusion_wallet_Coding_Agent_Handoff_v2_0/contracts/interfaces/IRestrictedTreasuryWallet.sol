// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice fusion_wallet V3 specification interface. This is NOT a wallet implementation.
interface IRestrictedTreasuryWallet {
    enum ActionKind { DEPOSIT, WITHDRAW, REBALANCE }
    enum PermissionTier { READ_ONLY, OWNER_APPROVED, AUTONOMOUS }

    struct VaultLimit { address vault; uint256 maxExposureRaw; }
    struct Policy {
        PermissionTier permissionTier;
        uint256 operatingBufferRaw;
        uint256 microMaxRaw;
        uint256 delayedMaxRaw;
        uint256 hardMaxRaw;
        uint256 dailyLimitRaw;
        uint32 delaySeconds;
        uint16 maxShareSlippageBps;
        address guardian;
        VaultLimit[] vaults;
    }
    struct Action {
        ActionKind kind;
        address sourceVault;
        address destinationVault;
        uint256 assets;
        uint256 minSharesOut;
        uint256 maxSharesBurn;
        uint256 expectedNonce;
        uint256 policyEpoch;
        uint64 deadline;
    }
    struct Queue {
        bool exists;
        bytes32 actionDigest;
        bytes32 sessionId;
        uint64 readyAt;
        uint64 expiresAt;
        Action action;
    }
    struct WalletState {
        bool configured;
        bool paused;
        uint256 policyEpoch;
        bytes32 policyHash;
        bytes32 mandateHash;
        bytes32 obligationsRoot;
        uint256 reservedObligationsRaw;
        uint256 actionNonce;
        uint256 dailyDayIndex;
        uint256 dailyUsedRaw;
        bytes32 sessionId;
        uint256 sessionStartEpoch;
        address sessionKey;
        uint64 sessionExpiresAt;
        uint256 sessionLimitRaw;
        uint256 sessionUsedRaw;
    }

    error Unauthorized();
    error WrongChain();
    error WrongLifecycle();
    error WalletPaused();
    error InvalidPolicy();
    error InvalidSession();
    error SessionExpired();
    error StalePolicy();
    error BadNonce();
    error ActionExpired();
    error ReadOnly();
    error UnsupportedAction();
    error ForbiddenVault();
    error CodeMismatch();
    error AssetMismatch();
    error InvalidAmount();
    error HardLimitExceeded();
    error DailyLimitExceeded();
    error SessionLimitExceeded();
    error ApprovalRequired();
    error ApprovalExpired();
    error ReserveViolation();
    error ExposureExceeded();
    error InsufficientLiquidity();
    error ShareBoundViolation();
    error AccountingMismatch();
    error ResidualAllowance();
    error QueueRequired();
    error QueueAlreadyExists();
    error QueueMismatch();
    error QueueNotReady();
    error QueueExpired();
    error NoQueue();
    error InvalidDeadline();
    error InvalidObligationCommitment();

    event PolicyConfigured(uint256 indexed policyEpoch, bytes32 policyHash, bytes32 mandateHash);
    event ObligationsCommitted(uint256 indexed policyEpoch, bytes32 indexed root,
        uint256 reservedRaw, bytes32 mandateHash);
    event SessionStarted(bytes32 indexed sessionId, address indexed key, uint256 indexed policyEpoch,
        uint64 expiresAt, uint256 limitRaw, bytes32 mandateHash);
    event SessionRevoked(bytes32 indexed previousSessionId, address indexed previousKey,
        uint256 indexed policyEpoch, bytes32 mandateHash);
    event ActionApproved(bytes32 indexed digest, uint256 indexed policyEpoch,
        uint256 expectedNonce, uint64 validUntil);
    event ActionApprovalRevoked(bytes32 indexed digest);
    event ActionQueued(bytes32 indexed digest, bytes32 indexed sessionId, uint256 indexed nonce,
        uint64 readyAt, uint64 expiresAt);
    event QueueCancelled(bytes32 indexed digest, address indexed actor, uint256 consumedNonce);
    event QueueExpiredEvent(bytes32 indexed digest, uint256 consumedNonce);
    event QueueInvalidated(bytes32 indexed digest, bytes32 reasonCode, uint256 consumedNonce);
    event ActionExecuted(bytes32 indexed actionDigest, uint256 indexed nonce,
        bytes32 indexed sessionId, ActionKind kind, address sourceVault,
        address destinationVault, uint256 assets, uint256 sharesBurned,
        uint256 sharesMinted, uint256 cashAfter, uint256 policyEpoch);
    event Paused(address indexed actor, uint256 indexed policyEpoch, bytes32 reasonCode, bytes32 mandateHash);
    event Resumed(uint256 indexed policyEpoch, bytes32 indexed sessionId, bytes32 mandateHash);
    event OwnerWithdrawal(address indexed vault, uint256 assets, uint256 sharesBurned);
    event OwnerRecovery(uint256 assets);
    event OwnerShareRecovery(address indexed vault, uint256 shares);

    function owner() external view returns (address);
    function asset() external view returns (address);
    function deploymentChainId() external view returns (uint256);
    function guardian() external view returns (address);
    function trustedVaults() external view returns (address[2] memory);
    function getPolicy() external view returns (Policy memory);
    function getState() external view returns (WalletState memory);
    function getQueue() external view returns (Queue memory);
    function approvalValidUntil(bytes32 digest) external view returns (uint64);
    function hashAction(Action calldata action) external view returns (bytes32);
    function configurePolicy(Policy calldata policy) external;
    function setObligationCommitment(bytes32 root, uint256 reservedRaw) external;
    function startSession(address key, uint64 expiresAt, uint256 sessionLimit) external;
    function resume(uint256 expectedEpoch) external;
    function pause(bytes32 reasonCode) external;
    function revokeSession() external;
    function approveAction(Action calldata action, uint64 validUntil) external returns (bytes32 digest);
    function revokeActionApproval(bytes32 digest) external;
    function queueAction(Action calldata action) external returns (bytes32 digest);
    function cancelQueuedAction(bytes32 digest) external;
    function expireQueuedAction() external;
    function execute(Action calldata action) external returns (bytes32 digest);
    function ownerWithdraw(address vault, uint256 assets, uint256 maxSharesBurn) external;
    function ownerRecoverUnderlying(uint256 assets) external;
    function ownerRecoverShares(address vault, uint256 shares) external;
}
