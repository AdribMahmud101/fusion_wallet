# V3 canonical hashing

All hashes are Keccak-256 of Solidity abi.encode, not SHA3-256, packed encoding, EIP-712 or JSON. TAG(name)=keccak256(UTF8(name)). Use exact field order and ABI widths below. Hash vectors use illustrative addresses, never deployment addresses. Runtime Solidity/Rust parity remains a required implementation test.

PolicyHash =
keccak256(abi.encode(TAG("FUSION_WALLET_POLICY_V3"), uint8 permissionTier,
uint256 operatingBufferRaw, uint256 microMaxRaw, uint256 delayedMaxRaw,
uint256 hardMaxRaw, uint256 dailyLimitRaw, uint32 delaySeconds,
uint16 maxShareSlippageBps, address guardian,
keccak256(abi.encode((address,uint256)[] sortedVaultLimits)))).

Obligation row hash = keccak256(abi.encode(bytes32 idHash,uint256 amountRaw,uint64 dueAt)).
ObligationsRoot = keccak256(abi.encode(bytes32[] rowHashes)).
Sort records by idHash ascending; forbid duplicates. Empty array has its normal nonzero ABI Keccak hash.
idHash = keccak256(UTF8(canonical internal obligation ID)); the ID is an opaque normalized ASCII identifier, not a private payee name.

SessionId =
keccak256(abi.encode(TAG("FUSION_WALLET_SESSION_V3"),uint256 chainId,address wallet,
uint256 sessionStartEpoch,address sessionKey,uint64 sessionExpiresAt,uint256 sessionLimitRaw)).

MandateHash =
keccak256(abi.encode(TAG("FUSION_WALLET_MANDATE_V3"),uint256 chainId,address wallet,
uint256 policyEpoch,bytes32 policyHash,bytes32 obligationsRoot,uint256 reservedObligationsRaw,
bytes32 sessionId,address sessionKey,uint64 sessionExpiresAt,uint256 sessionLimitRaw,bool paused)).

With no session: sessionId=bytes32(0), sessionKey=address(0), expiry=0, limit=0.
SessionId remains fixed over pause/resume. MandateHash changes with epoch/paused/obligations.
Spent amounts are checked from current state but not included in the digest; actionNonce prevents replay.

Action tuple =
(uint8 kind,address sourceVault,address destinationVault,uint256 assets,
uint256 minSharesOut,uint256 maxSharesBurn,uint256 expectedNonce,uint256 policyEpoch,uint64 deadline).

ActionDigest =
keccak256(abi.encode(TAG("FUSION_WALLET_ACTION_V3"),uint256 chainId,address wallet,
bytes32 mandateHash,bytes32 sessionId,Action action)).

CandidateId =
keccak256(abi.encode(TAG("FUSION_WALLET_CANDIDATE_V3"),bytes32 snapshotBlockHash,bytes32 actionDigest)).
HOLD uses literal "HOLD" in the planner schema and has no executable digest.

Use all-zero unused vault address and bound fields only where the action shape explicitly permits them.
Hex strings are normalized lowercase for transport; address checksum is a display aid, not a change of bytes.
Net-benefit estimates may be signed decimal strings; they are not token amounts and are not hashed into the on-chain Action.
Raw uint256 values are canonical base-10 strings without signs/leading zeros (except "0").
Reject overflow beyond 2^256-1 even if the JSON schema’s digit pattern accepts the length.
Timestamp JSON integers are bounded to 2^53-1; native Solidity fields are uint64.
