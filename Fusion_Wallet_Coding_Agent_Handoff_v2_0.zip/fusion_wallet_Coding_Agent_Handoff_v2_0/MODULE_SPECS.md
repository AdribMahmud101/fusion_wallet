# Module and submodule implementation contracts

All NEW paths are proposed under Fintech_Wallet_Agent. Rust financial logic stays in fusion-core; Android code stays below fusion-core-android. The generated fusion-core-kotlin source is an output, never a hand-edited source of truth.

## M0 Mandate and obligation management

M0.1 DeploymentManifest loader: chainId, RPC URL, wallet/asset/two vault addresses, decimals=6, code hashes, ABI version, confirmation depth, demo flag and genesis/deployment block. Load from signed build configuration, not model output. Reject chain IDs other than 31337/84532 for this release. Verify eth_chainId and every required code hash before showing “connected”. A policy toggle does not mutate confirmed chain state.

M0.2 Owner drafts: accept human text locally, normalize Unicode whitespace, and offer structured form correction for ambiguity. Require explicit decimal scale and currency. The model may propose a draft but Rust parses canonical amounts and validates cap ordering. Use decimal strings and checked integer multiplication; reject scientific notation, negatives, overflow, nonfinite numbers and overprecision rather than rounding silently.

M0.3 ObligationLedger: immutable ID, private label/payee alias, amountRaw, dueAt, status, revision and owner confirmation reference. Only ACTIVE rows contribute R. Each content revision has a new commitment; duplicate ID/version is idempotent, conflicting duplicate is an error. Pending activation does not appear as protected confirmed cash. Display draft reservations separately and block planning while a change affecting free cash is pending.

M0.4 CommitmentBuilder: sort active records by bytes32 idHash ascending; require unique IDs; hash each ABI-encoded (idHash, amountRaw, dueAt) row, then hash the ABI bytes32[] list. Owner sees the exact total and count and signs setObligationCommitment. Record that a root is a commitment, not private invoice disclosure or chain verification of real-world invoice authenticity.

M0.5 Session lifecycle: configure policy while paused, commit obligations, start a new session with <=24h expiry, then resume with expectedEpoch. A fresh owner review is mandatory after a halt. Every owner operation is sent through a trusted signer screen and canonical confirmation. Keep pending/draft/confirmed state distinct.

M0.6 Preferences: privacy mode is independent of on-chain permissionTier. A model cannot increase either. Settings show proposed and confirmed values; remove fixture-only changes.

Outputs: immutable draft/confirmed policy views, obligation revision/root/total and actionable owner requests. No key bytes.

## M1 Perception and deterministic reflex

M1.1 ReadSnapshot: one block number and hash for balanceOf, vault shares, convertToAssets/previewDeposit/previewWithdraw/maxWithdraw, policy, obligations, session, action nonce, queue and daily usage. Record raw chain values before formatting. If a provider cannot support the required block read, reject the snapshot.

M1.2 ValidateSnapshot: verify chain/code/asset/decimals, configured mode, session expiry, no unexplained nonce changes, canonical block and data completeness. Vault marked value is not guaranteed withdrawable cash. maxWithdraw and current previews are separately checked.

M1.3 Fees: use exact intended calldata and sender; estimate gas and L1 data cost where applicable, apply declared buffers and impose signer-owned maxima. Native-token fee to DemoUSD conversion is explicitly scenario-priced until a verified price feed exists. Financial calculations disclose that assumption. An estimate is not a fee guarantee.

M1.4 Risk feed: depeg, stale feed, wrong chain, changed code, accounting divergence, corrupt state or lost signer connection can latch. The arena’s 0.97 price is an injected scenario value, never claimed as a live oracle or actual stablecoin depeg. Pin demo trigger to price <=0.98 with fresh configured feed; stale/missing risk input halts for inability to assess rather than declaring a depeg.

M1.5 Reflex ordering: increment incident/route epoch and durably latch locally; block signing; request guardian pause; record timings; obtain explanation from local model afterwards. Pause failure stays visible and retried within fee limits. Do not wait for inference, AHEM, a UI coroutine or network pause confirmation before closing the local gate.

Snapshot TTL: 30 seconds or five blocks, whichever first; fee quote TTL: 15 seconds. Record both monotonic elapsed time and chain time. Time rollback never renews a TTL. Persist timestamps for recovery, but obtain fresh values after restart.

## M2 Deterministic candidates and local AI

M2.1 CandidateGenerator: use checked raw units. Maximum candidate assets is bounded by hard/day/session budget, vault liquidity, current cash surplus and destination exposure. HOLD always exists. DEPOSIT consumes only sweepable cash; WITHDRAW returns assets to the treasury; REBALANCE atomically withdraws then deposits to the other vault. No model-selected token, recipient, router or arbitrary calldata.

M2.2 Economics: compare expected incremental yield over an explicit horizon against buffered fees and minimum net benefit. Use simple annualized basis points for scenario forecasts, not a guaranteed APY. Formula: grossRaw=floor(assetsRaw * incrementalRateBps * horizonSeconds / (10000*31536000)); netRaw=grossRaw-feeRaw. Net benefit is a signed decimal derived value; token amounts and budgets remain unsigned. Default demo minimum net benefit=10,000 raw units (0.01 DemoUSD). Derive break-even horizon with ceiling division. If the rate benefit is <=0 or fee cannot be estimated, HOLD. Deposits use destination rate; rebalance uses destination minus source. Safety withdrawals can bypass the yield-benefit criterion but never authority/cap/share rules.

M2.3 Candidate bound fields: actionDigest, candidateId, snapshot block hash, policyEpoch, obligation root/total, expected nonce, assets, share bounds, deadline, cost assumptions and risk rationale. Sort deterministically; same inputs produce same candidates. At most seven plus HOLD. No changes after model selection.

M2.4 PlannerAdapter: send only necessary structured facts plus bounded untrusted user goal to local MNN. Output is candidateId and a reasonCode from a finite vocabulary. The app never executes streamed partial output. Strictly reject unknown keys, unknown IDs, malformed JSON, trailing instructions or mismatched request/route generation. One format retry within the total budget; otherwise HOLD.

M2.5 Resource control: one model job at a time, <=2,048 input tokens and <=256 output tokens, 20s generation target and 25s overall request budget. These are desired limits to validate on the chosen device. If cold load is longer, show a separate setup phase; do not disguise it as inference latency. A deadline invalidates the request immediately even if native compute takes longer to terminate. Never start another native call on a possibly running handle.

M2.6 Planner modes: actual MNN only in testnet core. Deterministic fixture selector is allowed exclusively in visibly labelled local test/arena mode. It cannot satisfy the real-model gate. AHEM statuses accompany the output under its own rules.

M2.7 Decision hysteresis: one outstanding action, no repeated sweep on the same snapshot, explicit cooldown 60s after reconciliation, and a new snapshot/rate/cost evaluation before the next decision. On-chain daily/session caps remain the hard anti-drain boundary; a delay alone does not stop many valid small actions.

## M3 Independent policy and decoded approvals

M3.1 Preview is pure: no reserve mutation, no nonce allocation, no key load and no broadcast. It returns all rule outcomes, bucket before/after values, tier, approval requirement and exact action/digest.

M3.2 Risk amount classification: 0<assets<=10 => IMMEDIATE; 10<assets<=100 => DELAYED; assets>100 => OWNER_REQUIRED, all within hardMax. Permission OWNER_APPROVED adds approval to every tier. READ_ONLY cannot sign. Mid-tier delay cannot be waived by an owner approval.

M3.3 OwnerApprovalRequest: show chain and wallet, operation, both exact vault addresses with friendly names, asset/decimals, raw+formatted amount, min minted shares/max burned shares, reserve target and before/after cash, fee ceiling, deadline, delay and session budget. The signer independently reconstructs the same card from canonical fields. A changed field invalidates consent. Tap “confirm” is not an on-chain approval until a successful canonical receipt is present.

M3.4 Share bounds: calculate minSharesOut=floor(previewDeposit*(10000-toleranceBps)/10000), maxSharesBurn=ceil(previewWithdraw*(10000+toleranceBps)/10000), with positive results. Clamp neither to zero nor an old value. After model/approval/delay, recompute current previews and require the original bounds still hold; otherwise cancel/expire and propose a new action with new consent.

M3.5 Preflight: exact sender/call/value=0 at current block, no overrides; validate same queue/epoch/nonce and current availability. Envelope expiry <=30s/five blocks, fee <=15s. Signer repeats all critical checks before allocating bytes. An old owner approval does not approve a different action after refresh.

M3.6 Middle queue: first sign queueAction, reconcile its event and record readyAt/expiresAt. Do not pre-sign execute. At readyAt, fetch a fresh snapshot and preflight the exact stored action. If conditions changed beyond its bounds, do not “repair” calldata. Request cancel or wait for expiry. No catch-up batch executes after device downtime.

## M4 Authority and signing

M4.1 Solidity restricted wallet is the final financial boundary. Detailed lifecycle, hashes, errors and events are in contracts/ONCHAIN_SPEC.md.
M4.2 Signer APK owns raw bytes, nonce selection and broadcast. The app holds attempt handles and hashes only.
M4.3 Owner operations use a trusted signer activity plus fresh authentication, never an automatic Binder method. Automatic methods are restricted to the active session and typed allowed operations.
M4.4 Guardian authority is pause/cancel only. It cannot resume, recover, edit limits or approve a large action.
M4.5 Keys: independent owner/session/guardian addresses; no reused key across roles. Fresh install begins latched. Backups and analytics cannot contain key ciphertext, model context or private invoice records. Lost owner wrapping key means this disposable demo identity is unrecoverable; never silently reset the same treasury as “new”.

## M5 Durability and lifecycle

Implement the state machine and two-store protocol in STORAGE_AND_RECOVERY.md. Room/SQLite owns each app’s journal; Rust uses an explicit persistence adapter rather than mixing an unrelated JSON ledger. One journal writer per wallet/EOA. Transactions are locally ACID, but wallet and signer databases are not one atomic transaction.

Persist the request before asking the signer; signer persists prepared bytes before returning; worker persists the handle before requesting broadcast; signer persists BROADCAST_REQUESTED before invoking RPC. A network error after that marker is UNKNOWN, not safe to resend a different action. Restart queries by idempotency key and reconciles chain before any new attempt.

Corrupt storage, full disk, incomplete scan, ambiguous nonce or mismatched event/accounting latches the system. Owner-reviewed reset is only for a fresh disposable deployment, not a way to erase spent budgets.

## M6 Compose product

Replace MainViewModel’s demo constructor default with a dependency-injected TreasuryRepository/LocalPlanner/SignerClient. The real build cannot contain the executable demo selector/hash generator. Keep preview fixtures in debug/preview source sets.

Tokens becomes the three-bucket treasury view. Chat hosts the local plan and decoded intent card. Ledger shows authoritative transaction and obligation history. Settings shows confirmed policy and pending changes. System logs show sanitized measured events. Add an arena route and a pending-queue panel without rebuilding navigation.

Use a typed state machine rather than a single pending Pair. Disable double submission, preserve request IDs across rotation/process death, show UNKNOWN explicitly, and remove “executed” styling until reconciliation. All prices/yields/demo feeds and replay panels are labelled.

## M7 Evaluation and evidence

Maintain independent benign and malicious corpora, immutable expected outcomes, real runtime identity and raw per-case results. Test the inference boundary, the Rust checks and direct contract bypass separately. A rejected model response, rejected signer request and reverted chain call are distinct enforcement layers.

Produce a decision passport: request/model/runtime hashes; selected candidate; AHEM mode and coverage; policy/obligation/action digests; owner approval or queue event; fresh preflight; signer attempt; real transaction/receipt; transaction-level deltas; final status. Private prompts/invoices are not exported by default. Judge evidence uses synthetic test records and public transaction links.

Every final product claim is traceable to a passing gate. See VALIDATION_GATES.md for non-negotiable release rules and BENCHMARK_AND_DEMO.md for honest scoring evidence.
