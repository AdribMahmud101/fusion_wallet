#!/usr/bin/env python3
"""Meaningful document-contract checks. Not integrated application tests."""
import csv,copy,hashlib,json,re,subprocess,sys,tempfile
from pathlib import Path
from jsonschema import Draft202012Validator
from referencing import Registry,Resource
from reference_vectors import calc,check as check_vectors
from verify_release import validate
P=Path(__file__).resolve().parents[1]
def read(n):return json.loads((P/n).read_text())
def check_schema():
    d=read('contracts/domain.schema.json');s=read('contracts/signer.schema.json')
    ipc=read('contracts/ipc.schema.json')
    Draft202012Validator.check_schema(d);Draft202012Validator.check_schema(s);Draft202012Validator.check_schema(ipc)
    reg=Registry().with_resource(d['$id'],Resource.from_contents(d)).with_resource(s['$id'],Resource.from_contents(s)).with_resource(ipc['$id'],Resource.from_contents(ipc))
    mapping={'policy.json':'Policy','buckets.json':'TreasuryBuckets','snapshot.json':'SnapshotRef','action.json':'Action',
             'candidate.json':'Candidate','planner_request.json':'PlannerRequest','planner_response.json':'PlannerResponse','cloud_public.json':'CloudPublicRequest'}
    for name,kind in mapping.items():
        schema={'$ref':d['$id']+'#/$defs/'+kind}
        Draft202012Validator(schema,registry=reg).validate(read('fixtures/'+name))
    for o in read('fixtures/obligations.json'):Draft202012Validator({'$ref':d['$id']+'#/$defs/Obligation'},registry=reg).validate(o)
    Draft202012Validator(s,registry=reg).validate(read('fixtures/signer_prepare.json'))
    # Verify typed IPC routing and reject caller-supplied owner consent.
    ipc_validator=Draft202012Validator({'$ref':ipc['$id']+'#/$defs/SignerRequest'},registry=reg)
    ipc_validator.validate({'method':'prepare','payload':read('fixtures/signer_prepare.json')})
    owner={'method':'requestOwnerReview','payload':{'protocolVersion':'2.0.0','requestId':'review_01','reviewId':'owner_01','ownerOperation':{'method':'approveAction','action':read('fixtures/action.json'),'validUntil':1800000600}}}
    ipc_validator.validate(owner)
    owner['payload']['ownerApproved']=True
    assert list(ipc_validator.iter_errors(owner))
    iv=Draft202012Validator({'$ref':ipc['$id']+'#/$defs/InferenceRequest'},registry=reg)
    iv.validate({'method':'plan','payload':read('fixtures/planner_request.json')})
    assert list(iv.iter_errors({'method':'sign','payload':{'privateKey':'secret'}}))
    # A provider payload with any private/free-text field must fail.
    cloud=read('fixtures/cloud_public.json');cloud['goal']='CANARY_PRIVATE'
    assert list(Draft202012Validator({'$ref':d['$id']+'#/$defs/CloudPublicRequest'},registry=reg).iter_errors(cloud))
    bad=read('fixtures/signer_prepare.json');bad['privateKey']='CANARY_SECRET'
    assert list(Draft202012Validator(s,registry=reg).iter_errors(bad))
    a=read('fixtures/action.json');a['assets']='1e6'
    assert list(Draft202012Validator({'$ref':d['$id']+'#/$defs/Action'},registry=reg).iter_errors(a))
def check_math():
    b=read('fixtures/buckets.json');v={k:int(x) for k,x in b.items()}
    assert v['freeCashRaw']+v['reservedBackedRaw']==v['cashRaw']
    assert v['freeCashRaw']+v['reservedBackedRaw']+v['deployedRaw']==v['totalAssetsRaw']
    assert v['sweepableRaw']==max(v['cashRaw']-v['obligationTargetRaw']-v['bufferRaw'],0)
    policy=read('fixtures/policy.json')
    tier=lambda n:'IMMEDIATE' if n<=int(policy['microMaxRaw']) else 'DELAYED' if n<=int(policy['delayedMaxRaw']) else 'OWNER_REQUIRED'
    assert [tier(n) for n in [10000000,10000001,100000000,100000001]]==['IMMEDIATE','DELAYED','DELAYED','OWNER_REQUIRED']
    for v in read('vectors.json')['vectors']:
        original=v['expected']['actionDigest']
        c=copy.deepcopy(v['context']);c['chainId']=31337
        assert calc(v['policy'],c,v['obligations'],v['action'])['actionDigest']!=original
        for key in ['assets','expectedNonce','policyEpoch']:
            a=copy.deepcopy(v['action']);a[key]=str(int(a[key])+1)
            assert calc(v['policy'],v['context'],v['obligations'],a)['actionDigest']!=original
        ob=copy.deepcopy(v['obligations']);ob[0]['amountRaw']=str(int(ob[0]['amountRaw'])+1)
        assert calc(v['policy'],v['context'],ob,v['action'])['actionDigest']!=original
def check_coverage():
    rows=list(csv.DictReader((P/'acceptance_tests.csv').read_text().splitlines()))
    assert len(rows)==133 and len({r['id'] for r in rows})==133
    assert all(r['status']=='NOT_RUN' for r in rows)
    assert sum(r['profile']=='core' for r in rows)==119
    template=read('results.template.json')
    assert {r['id'] for r in rows}=={r['id'] for r in template['results']}
    errors,n=validate(template,read('integration-lock.template.json'),P/'integration-lock.template.json',P/'evidence','core',False)
    assert errors and n==119
    assert all(any(r['id']+':' in e for e in errors) for r in rows if r['profile']=='core')
    suite=read('scenarios/evaluation_cases.json')
    assert len(suite['benign'])==20 and len(suite['malicious'])==20
    assert len({x['id'] for side in ['benign','malicious'] for x in suite[side]})==40
    assert all(x['actionable'] for x in suite['benign'])
def check_links():
    required=['README_START_HERE.md','REPOSITORY_AUDIT.md','ARCHITECTURE.md','AGENT_HANDOFF.md','NEXT_AGENT_TODO.md',
              'MODULE_SPECS.md','ANDROID_AND_MNN.md','AHEM_INTEGRATION.md','ENHANCEMENTS_AND_UX.md',
              'STORAGE_AND_RECOVERY.md','VALIDATION_GATES.md','BENCHMARK_AND_DEMO.md',
              'contracts/ONCHAIN_SPEC.md','contracts/SIGNER_PROTOCOL.md','contracts/HASHING.md']
    for f in required:assert (P/f).is_file() and (P/f).stat().st_size>300,f
    solidity=(P/'contracts/interfaces/IRestrictedTreasuryWallet.sol').read_text()
    for method in ['setObligationCommitment','queueAction','cancelQueuedAction','expireQueuedAction','execute','approveAction','revokeSession']:
        assert 'function '+method+'(' in solidity
    assert 'private_key' not in solidity
if __name__=='__main__':
    check_schema();check_math();check_coverage();check_links();n=check_vectors()
    print(f'PACKAGE PASS: schemas/fixtures, negative payloads, treasury arithmetic, tier boundaries, {n} ABI reference vectors, digest mutations,133 acceptance definitions,40 evaluation definitions, required files and fail-closed NOT_RUN gate.')
    print('Runtime/device/model/chain tests: NOT_RUN in this package.')
