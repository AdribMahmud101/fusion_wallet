"""Synthetic unit checks of the report verifier; no application PASS results."""
import copy,csv,hashlib,json,tempfile,unittest
from pathlib import Path
from verify_release import validate,ROOT
class GateContract(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.p=Path(self.tmp.name)
        artifact=self.p/'synthetic.txt';artifact.write_text('Synthetic report-verifier fixture; not application evidence.')
        self.lock={'status':'RESOLVED','release_profile':'core','repositories':{'wallet':'1'*40},
            'mnn_aar_sha256':'2'*64,'model_identity':{'id':'fixture','revision':'fixture','weights_sha256':'3'*64,
            'tokenizer_sha256':'4'*64,'config_sha256':'5'*64,'license':'fixture'},
            'native_libraries':{'fixture.so':'6'*64},'deployed_contracts':{'fixture':True}}
        self.lp=self.p/'lock.json';self.lp.write_text(json.dumps(self.lock))
        cases=list(csv.DictReader((ROOT/'acceptance_tests.csv').read_text().splitlines()))
        identity={k:'fixture' for k in ('device','apk_sha256','model_sha256','hook_sha256','chainId','deployment','runId','txHash','captureTool')}
        self.report={'profile':'core','releaseCommit':'1'*40,'integrationLockSha256':hashlib.sha256(self.lp.read_bytes()).hexdigest(),
            'results':[dict(id=c['id'],status='PASS',environment=c['environment'],command='synthetic-test-fixture',
                exitCode=0,assertions=1,skipped=0,testNames=['synthetic-only'],identity=identity,
                evidence=[{'path':'synthetic.txt','sha256':hashlib.sha256(artifact.read_bytes()).hexdigest()}])
                for c in cases if c['profile']=='core']}
    def tearDown(self):self.tmp.cleanup()
    def run_gate(self):return validate(self.report,self.lock,self.lp,self.p,'core',False)[0]
    def test_accepts_structurally_complete_report(self):self.assertEqual(self.run_gate(),[])
    def test_missing_case_blocks(self):
        self.report['results'].pop();self.assertTrue(self.run_gate())
    def test_skip_blocks(self):
        self.report['results'][0]['skipped']=1;self.assertTrue(self.run_gate())
    def test_failed_exit_blocks(self):
        self.report['results'][0]['exitCode']=1;self.assertTrue(self.run_gate())
    def test_wrong_environment_blocks(self):
        self.report['results'][0]['environment']='mock';self.assertTrue(self.run_gate())
    def test_hash_mismatch_blocks(self):
        self.report['results'][0]['evidence'][0]['sha256']='0'*64;self.assertTrue(self.run_gate())
    def test_path_escape_blocks(self):
        self.report['results'][0]['evidence'][0]['path']='../outside';self.assertTrue(self.run_gate())
    def test_not_run_blocks(self):
        self.report['results'][0]['status']='NOT_RUN';self.assertTrue(self.run_gate())
    def test_duplicate_blocks(self):
        self.report['results'].append(copy.deepcopy(self.report['results'][0]));self.assertTrue(self.run_gate())
    def test_bool_assertion_blocks(self):
        self.report['results'][0]['assertions']=True;self.assertTrue(self.run_gate())
if __name__=='__main__':unittest.main()
