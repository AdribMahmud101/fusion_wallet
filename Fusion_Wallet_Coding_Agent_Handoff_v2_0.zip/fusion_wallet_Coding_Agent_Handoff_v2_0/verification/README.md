# Package verification

Create a local Python environment and install requirements.txt. These scripts validate this handoff, not the future product.

python3 verification/check_package.py
python3 verification/reference_vectors.py

The negative release-gate check is intentionally expected to exit1:
python3 verification/verify_release.py results.template.json --evidence-root evidence --lock integration-lock.template.json --profile core

The coding agent must create actual results.json and integration-lock.json after running the application suites. There are no passing runtime results in the template. See VALIDATION_GATES.md.
