#!/usr/bin/env python3
"""ABI/Keccak reference implementation, not on-chain execution."""
import json
from pathlib import Path
from eth_abi import encode
from eth_utils import keccak
ROOT=Path(__file__).resolve().parents[1]
def k(s):return keccak(text=s)
def hx(b):return '0x'+b.hex()
def hb(s):return bytes.fromhex(s[2:])
def calc(policy,ctx,obligations,action):
    limits=[(x['vault'],int(x['maxExposureRaw'])) for x in policy['vaults']]
    vh=keccak(encode(['(address,uint256)[]'],[limits]))
    ph=keccak(encode(['bytes32','uint8','uint256','uint256','uint256','uint256','uint256','uint32','uint16','address','bytes32'],
       [k('FUSION_WALLET_POLICY_V3'),['READ_ONLY','OWNER_APPROVED','AUTONOMOUS'].index(policy['permissionTier']),
        int(policy['operatingBufferRaw']),int(policy['microMaxRaw']),int(policy['delayedMaxRaw']),int(policy['hardMaxRaw']),
        int(policy['dailyLimitRaw']),policy['delaySeconds'],policy['maxShareSlippageBps'],policy['guardian'],vh]))
    oh=[keccak(encode(['bytes32','uint256','uint64'],[hb(o['idHash']),int(o['amountRaw']),o['dueAt']])) for o in sorted(obligations,key=lambda x:x['idHash'])]
    root=keccak(encode(['bytes32[]'],[oh]));reserved=sum(int(x['amountRaw']) for x in obligations)
    sid=keccak(encode(['bytes32','uint256','address','uint256','address','uint64','uint256'],
        [k('FUSION_WALLET_SESSION_V3'),ctx['chainId'],ctx['wallet'],int(ctx['sessionStartEpoch']),ctx['sessionKey'],ctx['sessionExpiresAt'],int(ctx['sessionLimitRaw'])]))
    mh=keccak(encode(['bytes32','uint256','address','uint256','bytes32','bytes32','uint256','bytes32','address','uint64','uint256','bool'],
        [k('FUSION_WALLET_MANDATE_V3'),ctx['chainId'],ctx['wallet'],int(ctx['policyEpoch']),ph,root,reserved,sid,ctx['sessionKey'],ctx['sessionExpiresAt'],int(ctx['sessionLimitRaw']),ctx['paused']]))
    at=(['DEPOSIT','WITHDRAW','REBALANCE'].index(action['kind']),action['sourceVault'],action['destinationVault'],
        int(action['assets']),int(action['minSharesOut']),int(action['maxSharesBurn']),int(action['expectedNonce']),int(action['policyEpoch']),action['deadline'])
    ah=keccak(encode(['bytes32','uint256','address','bytes32','bytes32','(uint8,address,address,uint256,uint256,uint256,uint256,uint256,uint64)'],
        [k('FUSION_WALLET_ACTION_V3'),ctx['chainId'],ctx['wallet'],mh,sid,at]))
    cid=keccak(encode(['bytes32','bytes32','bytes32'],[k('FUSION_WALLET_CANDIDATE_V3'),hb(ctx['snapshotBlockHash']),ah]))
    return dict(policyHash=hx(ph),obligationsRoot=hx(root),reservedObligationsRaw=str(reserved),sessionId=hx(sid),mandateHash=hx(mh),actionDigest=hx(ah),candidateId=hx(cid))
def check():
    vectors=json.loads((ROOT/'vectors.json').read_text())
    for v in vectors['vectors']:
        assert calc(v['policy'],v['context'],v['obligations'],v['action'])==v['expected'],v['name']
    return len(vectors['vectors'])
if __name__=='__main__':print(f'PASS: {check()} Python ABI reference vectors. Solidity/Rust parity NOT_RUN.')
