#!/usr/bin/env python3
"""Fail-closed evidence gate. It validates reports, not application behavior itself."""
import argparse,csv,hashlib,json,re,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(report,lock,lock_path,evidence_root,profile,include_cloud):
    errors=[]
    required_profiles={'core'} | ({'research'} if profile=='full' else set()) | ({'cloud'} if include_cloud else set())
    cases=list(csv.DictReader((ROOT/'acceptance_tests.csv').read_text().splitlines()))
    required={r['id']:r for r in cases if r['profile'] in required_profiles}
    if report.get('profile')!=profile: errors.append('report profile does not match requested profile')
    if not re.fullmatch(r'[0-9a-f]{40}',str(report.get('releaseCommit',''))): errors.append('releaseCommit missing/invalid')
    if report.get('integrationLockSha256')!=digest(lock_path): errors.append('integration lock digest mismatch')
    if lock.get('status')!='RESOLVED': errors.append('integration lock is not RESOLVED')
    if lock.get('release_profile')!=profile: errors.append('integration lock profile mismatch')
    for k in ('mnn_aar_sha256','model_identity','native_libraries','deployed_contracts'):
        if not lock.get(k): errors.append('unresolved lock field: '+k)
    if profile=='full' and not lock.get('ahem_hook_patch_sha256'): errors.append('unresolved AHEM patch')
    if lock.get('repositories',{}).get('wallet')!=report.get('releaseCommit'): errors.append('wallet lock commit differs from releaseCommit')
    if not re.fullmatch(r'[0-9a-f]{64}',str(lock.get('mnn_aar_sha256',''))): errors.append('invalid AAR digest')
    model=lock.get('model_identity')
    if isinstance(model,dict):
        for k in ('id','revision','weights_sha256','tokenizer_sha256','config_sha256','license'):
            if not model.get(k):errors.append('missing model identity '+k)
    else:errors.append('model_identity must be an object')
    if not isinstance(lock.get('native_libraries'),dict):errors.append('native_libraries must map names to digests')
    elif any(not re.fullmatch(r'[0-9a-f]{64}',str(v)) for v in lock['native_libraries'].values()):errors.append('invalid native digest')
    seen={}
    for r in report.get('results',[]):
        i=r.get('id')
        if i in seen:errors.append('duplicate result '+str(i))
        seen[i]=r
    for i,c in required.items():
        r=seen.get(i)
        if not r:errors.append(i+': missing');continue
        if r.get('status')!='PASS':errors.append(i+': '+str(r.get('status')));continue
        if r.get('environment')!=c['environment']:errors.append(i+': wrong environment')
        if not isinstance(r.get('command'),str) or not r['command'].strip():errors.append(i+': no command')
        if r.get('exitCode')!=0 or isinstance(r.get('exitCode'),bool):errors.append(i+': nonzero/missing exit code')
        if not isinstance(r.get('assertions'),int) or isinstance(r.get('assertions'),bool) or r.get('assertions',0)<1:errors.append(i+': no assertions')
        if r.get('skipped')!=0 or isinstance(r.get('skipped'),bool):errors.append(i+': skipped assertions')
        if not r.get('testNames'):errors.append(i+': no mapped test names')
        env=c['environment'];identity=r.get('identity',{})
        need={'android_device':('device','apk_sha256'),'real_model_device':('device','model_sha256','apk_sha256'),
              'real_mnn_hook':('device','model_sha256','hook_sha256','apk_sha256'),
              'anvil':('chainId','deployment','runId'),'base_sepolia':('chainId','deployment','txHash'),
              'network_capture':('device','apk_sha256','captureTool')}.get(env,())
        for key in need:
            if not identity.get(key):errors.append(i+': missing identity '+key)
        evidence=r.get('evidence',[])
        if not evidence:errors.append(i+': no evidence')
        for e in evidence:
            rel=e.get('path','')
            p=(evidence_root/rel).resolve()
            if not rel or not p.is_relative_to(evidence_root.resolve()):errors.append(i+': unsafe evidence path');continue
            if not p.is_file() or p.stat().st_size==0:errors.append(i+': missing/empty evidence '+rel);continue
            if not re.fullmatch(r'[0-9a-f]{64}',str(e.get('sha256',''))) or digest(p)!=e['sha256']:errors.append(i+': evidence digest mismatch '+rel)
    return errors,len(required)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('results',type=Path);ap.add_argument('--evidence-root',required=True,type=Path)
    ap.add_argument('--lock',required=True,type=Path);ap.add_argument('--profile',choices=['core','full'],default='core')
    ap.add_argument('--include-cloud',action='store_true');a=ap.parse_args()
    try:
        report=json.loads(a.results.read_text());lock=json.loads(a.lock.read_text())
        errors,n=validate(report,lock,a.lock,a.evidence_root,a.profile,a.include_cloud)
    except (OSError,ValueError,TypeError,KeyError,AttributeError) as e:
        print('BLOCKED: '+str(e));return 1
    if errors:
        print(f'RELEASE BLOCKED: {len(errors)} issues across {n} required cases')
        for e in errors[:30]:print('- '+e)
        if len(errors)>30:print(f'- ... {len(errors)-30} more')
        return 1
    print(f'REPORT GATE PASS: {n} required cases with evidence; review raw artifacts and CI HEAD before release.')
    return 0
if __name__=='__main__':sys.exit(main())
