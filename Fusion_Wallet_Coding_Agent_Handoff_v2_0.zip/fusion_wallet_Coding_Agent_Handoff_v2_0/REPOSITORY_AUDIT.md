# Repository audit and reuse decisions

Review date: 16 October 2026. All paths below are relative to the named repository. Branch heads were resolved through GitHub, then shallow clones at the same commits were inspected locally. No repository source was changed. No AGENTS.md or CLAUDE.md was present in any reviewed tracked tree.

## Pinned baseline

| Repository | Branch | Commit | Reuse |
| --- | --- | --- | --- |
| Fintech_Wallet_Agent | main | e5ae118a6af3b31165e6167fdbf3cc971d31b627 | Product repository, Compose screens, Rust structure, Alloy, UniFFI and tests |
| mnn-android-sdk | master | 5c8f61f47c1afedf86cd1ae79d6df358613c6436 | Kotlin MNNLlm API, JNI bridge and native packaging |
| ahem | master | 8832419511ff57d82d811fc433f8ba5829305eb4 | Grounding, TensorLogic bridge, rule packs, callback/retry abstractions |

Inventory: 98, 348 and 56 tracked files respectively. These are source snapshots, not a dependency lock for the future integrated build. Record new commit IDs and AAR/model/native-library digests after every implementation change.

## Wallet application

The strongest existing asset is a complete Compose shell. Keep MainActivity, FusionWalletApp, theme, navigation, ChatFeed, TokensScreen, LedgerScreen, SettingsDrawer and SystemLogTerminalSheet. Extend PreFlightGuardrailCard into the decoded intent card. Replace the data source and state model beneath the screens.

The README accurately says the UI runs on demo data. MainViewModel defaults to DemoIntentSource; init logs a model name, 118 ms latency and armed Rust status without probing a runtime. DemoData fixes chain ID 1, token balances and daily spend. DemoIntentSource parses a number/address with regex, computes atomic amounts through Double/Long and fabricates a 32-byte-shaped hash. None of these is evidence of inference, FFI execution or a real chain receipt. Settings currently update UI state while preflight rereads static DemoData. Release uses unsigned, unminified APK settings.

The Rust implementation is substantial and reusable, but its current transfer model differs from treasury management:

| Finding | Exact implementation evidence | Required change |
| --- | --- | --- |
| Transfer-only engine | models.rs Action has Transfer/Swap/Stake; guardrails.rs check_supported_action accepts only Transfer | New TreasuryAction with DEPOSIT/WITHDRAW/REBALANCE/HOLD; no arbitrary recipient in delegated path |
| No destination allowlist | guardrails.rs check_whitelisted_assets checks token contracts; check_destination validates only syntax/nonzero | Pin two vault addresses and wallet receiver; do not describe the current asset list as a recipient allowlist |
| Float policy arithmetic | AiIntent.amount, LedgerState.spent_usd and daily/transaction caps use f64 | Decimal raw-unit strings at boundaries; checked U256 integer arithmetic throughout financial rules |
| No real USD price conversion | resolve_amount/atomic_to_usd treats whole token quantity as notional; WETH is in built-ins | Restrict core profile to DemoUSD; never present WETH quantity as USD |
| Mainnet defaults leak into a test task | config.rs built-in Ethereum tokens/default chain; UI RPC points at Base mainnet while demo chain is Ethereum | Deployment manifest with exact chain/token/vault/code hashes; allow only Anvil 31337 or Base Sepolia 84532 in this release |
| Corrupt state restores zero | Ledger::open catches read errors; read_state resets invalid version/day/notional | Fail closed on corrupt/future state; explicitly provision a new ledger; reconcile chain before recovery |
| Reservation not durable before send | GuardrailEngine::evaluate changes memory; commit persists only after send returns | Write-ahead intent/reservation journal and separate signer store |
| Broadcast hash treated as success | executor::broadcast returns pending.tx_hash without a receipt | BROADCAST/UNKNOWN/MINED/CONFIRMED/RECONCILED states; no success before canonical evidence |
| Ambiguous failure releases budget | router.rs releases on every broadcast error | Preserve reservation on timeouts/connection loss after send may have occurred |
| Panic claim is unsafe | guard_panics says “no funds were moved” regardless of phase | Return uncertainty with attempt ID; reconcile before retry |
| Keys cross the UI FFI boundary | execute_intent accepts private_key: String; LoadedWallet::load runs before guardrail evaluation | Remove this export from the product path; key-handle/typed signer IPC only |
| Key wiping is incomplete in scope | Rust wraps incoming String, but normalised clones and Kotlin/JNA copies exist | No raw key in main UI/LLM; zeroize owned buffers without promising JVM-string erasure |
| Concurrent sends not coordinated durably | A provider is built per route; no persisted signer nonce queue | One live transaction attempt per agent EOA, deterministic idempotency |
| Missing treasury backend | No wallet Solidity implementation, vault adapters, pinned snapshots or receipt reconciler found | Implement M1–M5; do not wire DemoIntentSource directly to old executeIntent |
| FFI preview is only a comment | DemoData names preview_intent as future seam, but lib.rs exports execute_intent/configure_wallet | Add actual preview and plan exports; regenerate bindings, never edit generated Kotlin |

The no-mock source audit passed locally. This proves absence of its scanned markers in Rust production source, not transaction correctness. README reports 121 tests; 116 explicit Rust test annotations were found by a simple static scan. Generated/parameterized tests may affect totals. Neither number was independently executed here. cargo, rustc, kotlinc, adb and forge were unavailable. No GitHub Actions runs were returned for this repository at review time.

validate.sh is a useful starting point, but its cargo doc pipeline ends in “|| true”, which masks documentation errors; a Kotlin compilation pipeline also masks exit status before a later Java step. Preserve direct command exit codes and make required skipped tests fail release. A clean source audit cannot replace JNI/device/chain tests.

## MNN Android SDK

Reuse com.mnn.sdk.MNNLlm.load(configPath), chat(), responseFlow(), configuration and metrics. The bundled engine is declared 3.6.1; shipped ABIs are arm64-v8a and armeabi-v7a. Product target is arm64-v8a first. There is no x86_64 native set in this snapshot. A model downloader is in the sample app; it is not automatically a dependency-free SDK provisioning API.

Latest reviewed CI run 38453265247 at the pinned commit:
- SDK release AAR compilation: success.
- JNI import check: failure on MNN::Interpreter::createFromBuffer(void const*, unsigned int).
- Unit tests, lint, R8 consumer build/check and artifact upload: skipped after that failure.

This does NOT establish a broken arm64 runtime. The workflow selects the first libmnn-jni-bridge.so with find/head, then compares it against arm64 libraries regardless of the bridge ABI. Local nm inspection found the expected unsigned-int symbol in ARMv7 libMNN.so and unsigned-long symbol in arm64 libMNN.so; Interpreter.hpp takes size_t. A cross-ABI false positive is the leading explanation. Fix the check to enumerate ABI-matched pairs and rerun before changing ABI declarations. Do not silence the check or replace size_t with a forced width.

Further source-level risks to verify:

| Area | Finding and implication |
| --- | --- |
| Documentation drift | README still describes a handwritten vtable and no interrupt, while llm.hpp is a fuller vendored declaration and nativeStop writes USER_CANCEL through getContext. Code and device evidence take precedence; refresh README after proving behavior. |
| Cancellation | Native stop exists. It is not proof of a hard wall-clock stop if a kernel stalls. chat() uses structured coroutine work; chatFlow directly blocks inside the flow; responseFlow uses a separate worker. Treat them as distinct paths. |
| Lifetime/concurrency | Shared history, native reset, config and handle are not protected by a single generation mutex. chatFlow is not counted by the same in-flight scheme as chat/responseFlow; destroy can break its wait on interruption. Review races before simultaneous calls, timeout/reuse or disposal. |
| Input templating | Blocking chat now uses native chat history; streaming paths still build prompts/reset. Require candidate-output tests on the exact chosen API, not only the sample chat screen. |
| Instrumentation | Real-model tests use assumeTrue when model/ABI is unavailable. multiTurnRetainsHistory checks nonempty text, not correct recall. Those can pass or skip without establishing required behavior. |
| Packaging | SDK AGP/Kotlin pins differ from the wallet. Prefer a built, checksum-pinned local Maven artifact with POM dependencies; do not paste an independent root build into the wallet. Validate libc++ and all native libraries in the final APK. |
| Stub source | MNNStubImpl.kt exists for generic inference/testing paths. Product health must prove real native MNNLlm calls and reject any stub fallback. |
| AHEM interoperability | nm found none of the required ahem_* / latent-hook exports in bundled libllm.so for either ABI. Adding the Rust crate alone cannot activate tensor enforcement. |

No SDK device run or model benchmark was performed here. Preserve the working SDK as baseline while fixing targeted integration gates. Do not rewrite it wholesale.

## AHEM research project

AHEM supplies real Rust grounding and TensorLogic integration, dynamic rule candidates, callback telemetry and bounded retry abstractions. It is a research base with several different experimental domains (robotics, BSPWM and local/cloud routing). A treasury-specific latent boundary is not already calibrated or connected.

Critical integration findings:

1. src/mnn_ffi.rs imports get_lfm_latent_pointer, release_lfm_latent_pointer, gate registration, token ban, KV rewind, sampling and ahem_llm_* functions. The bundled SDK exports none of them.
2. mnn_hooks/mnn_lfm_latent_hook.cpp is explicitly a drop-in template. ensure_dense_layout has a TODO and simply returns the tensor. capture_pre_lm_head_latent is not wired into a checked-in MNN forward implementation.
3. Its getter takes a lock_guard then returns a pointer; the lock is released on return. Rust expects the critical section to last until release_lfm_latent_pointer, which the template does not implement. This is a concrete lifetime contract mismatch.
4. The callback validates positive dimensions but lacks a proved byte-length/stride/dtype/session contract. It allocates arrays/maps and snapshots, so “zero heap allocation” is not true for the full callback.
5. Some prefill/error/shape-mismatch branches return ALLOW for step <= 0. Those must not be interpreted as a clean security evaluation; no action is authorized until the complete result has valid coverage.
6. Global active-session/null-handle operations, raw callback pointers and registration lifetime require serialization and explicit teardown. Rust panics must not unwind across C ABI.
7. Callback telemetry invokes query_desktop_context (BSPWM) during evaluation. Strip desktop process calls from the mobile hot path. The app must not incorporate AHEM’s exec_bash/exec_bspc capabilities.
8. SemanticRouter hardcodes 1,024 features, a 32x32 map and latent region assignments. This is not proof that arbitrary Qwen hidden coordinates encode privacy or risk. Derive dimensions and calibrate against the exact model/quantization.
9. The calibration JSONL has 54 eight-dimensional samples (25 positive, 29 negative), without evidence here that they are activations of the wallet model. ahem_calibrate trains and verifies on the same samples, and saves only scale/bias while omitting learned w. It cannot support held-out treasury ASR/FBR claims or reproduce the learned projection.
10. Live MNN integration, killswitch and retry tests are ignored unless explicitly enabled in a prepared environment. A default cargo test omits the defining native behavior. No Actions runs were returned.
11. AHEM lacks a root license file/license declaration in the reviewed snapshot. The wallet Cargo package declares MIT but has no root LICENSE. Confirm project-owner licensing and carry notices before redistribution; this does not block private design work.

Use AHEM as an additional refusal/telemetry layer with OFF, SHADOW and ENFORCED modes. Core deterministic and contract rules always run. AHEM ALLOW can never waive them. ENFORCED with missing hook, stale coverage, wrong model or evaluation error must HOLD. SHADOW is clearly labelled and cannot be advertised as enforcement. No claimed prompt-injection immunity follows from a tensor-level hook alone.

## Review evidence and limitations

Locally executed: Python source no-mock audit (PASS); ELF symbol inspection on both bundled ABIs; tracked-file inventory and exact commit check; extraction of all three PDF pages. GitHub CI evidence is retrieved, not rerun. Rust/Android/model/Foundry suites are BLOCKED here, not PASS. The architectural diagrams, interfaces, fixtures and tests in this package are proposed implementation contracts.

Durable source links:
- https://github.com/AdribMahmud101/Fintech_Wallet_Agent/tree/e5ae118a6af3b31165e6167fdbf3cc971d31b627
- https://github.com/AdribMahmud101/mnn-android-sdk/tree/5c8f61f47c1afedf86cd1ae79d6df358613c6436
- https://github.com/AdribMahmud101/mnn-android-sdk/actions/runs/38453265247
- https://github.com/AdribMahmud101/ahem/tree/8832419511ff57d82d811fc433f8ba5829305eb4
