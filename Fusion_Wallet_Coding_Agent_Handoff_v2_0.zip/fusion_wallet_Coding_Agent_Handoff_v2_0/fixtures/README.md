# Illustrative contract fixtures

These are schema/hash examples, not actual runtime output or deployment addresses. Timestamps and elapsedMs are illustrative; no model result or performance claim is established. The action is a 50 DemoUSD mid-tier rebalance with a 600-second action lifetime and a separate 30-second preflight envelope. Queue readyAt is established by its actual receipt and is not fabricated here.

The three vectors are independent examples sharing nonce7, not a sequential execution plan. The wallet and model must obtain fresh real state before any transaction.
