# fusion_wallet repository grounded implementation handoff
Version 2.0 | 16 October 2026 | Topic F Agent Wallet

Continue AdribMahmud101/Fintech_Wallet_Agent. Preserve its Compose interface and reusable Rust core. Integrate the pinned mnn-android-sdk. Integrate AHEM through an explicitly tested native hook; its research library is not a drop-in tensor guard for the bundled SDK.

This package replaces the v1.0 implementation baseline. It defines the full target, all five enhancements from the supplied report, ordered implementation work, exact authority and interface contracts, and release evidence requirements. It is an architecture and implementation handoff, not a claim that the integrated application is built. Repository runtime suites were not run in this review because the Rust/Android/Foundry toolchains, device, patched MNN runtime and weights were unavailable.

Start in this order:
1. REPOSITORY_AUDIT.md — existing code, verified gaps, pinned sources.
2. ARCHITECTURE.md — complete target and boundaries.
3. AGENT_HANDOFF.md and NEXT_AGENT_TODO.md — what to change, in order.
4. MODULE_SPECS.md, ANDROID_AND_MNN.md, AHEM_INTEGRATION.md.
5. contracts/ONCHAIN_SPEC.md, contracts/SIGNER_PROTOCOL.md, STORAGE_AND_RECOVERY.md.
6. ENHANCEMENTS_AND_UX.md and VALIDATION_GATES.md.
7. acceptance_tests.csv and scenarios/evaluation_cases.json — implement and run, do not mark these definitions as passing tests.

The authoritative machine contracts are contracts/domain.schema.json, contracts/signer.schema.json, contracts/ipc.schema.json and contracts/interfaces/IRestrictedTreasuryWallet.sol. The Solidity file is a specification interface, not an implementation. Hash formulas and executable reference vectors are in contracts/HASHING.md and vectors.json. Paths marked NEW do not exist in the reviewed repositories.

Run verification/check_package.py to validate this handoff. Run verification/verify_release.py only against real implementation results. The supplied results.template.json contains NOT_RUN entries and MUST fail the release gate. Passing package checks does not pass product tests.

The Markdown master contains the full text. The Word review is the short decision and implementation brief. Do not carry the v1.0 React/Fastify/Linux-socket stack or V2 action digests into this native V3 contract design. Old files remain useful history, not active implementation instructions.

For a single continuous document, open FULL_BASE_ARCHITECTURE.md. The 10-page fusion_wallet_Architecture_Review_v2_0.docx is the decision brief. REQUIREMENT_TRACEABILITY.md maps the supplied enhancements to acceptance IDs; VALIDATION_REPORT.md states exactly what was checked in this task. SHA256SUMS.txt records archive file digests.
